<?php
session_start();
// Put this whole folder in a subfolder of www; fill up the details in this page, and then open in a browser from localhost/ your server name
?>

<html>
<head>
<title>phpMyTable</title>
</head>

<body>
  <h1>phpMyTable</h1>
  <h2>Patients</h2>
  <p>This is the basic table of a list of patients; view a linked table of <a href="results.php">Lab results</a></p>
<?php
require_once('template.php');
extract($_SESSION);

// Configuration; fill up these details
$opts['host'] = "";
$opts['db'] = "";
$opts['username'] = "";
$opts['password'] = "";
$opts['table'] = "";
$opts['primary_key'] = "";
$opts['results_per_page'] = 10;
$opts['readonly'] = false; // If the table is readonly
$opts['readonly_fields'] = array('Id');
$opts['refs'] = array( // Which fields should have defined values
    'Sex'=>array('M','F')
);
$opts['sort']= array(); // Field list to sort with
$opts['dropdown'] = array( // Which fields are linked to another table; a dropdown will appear automatically
    'Name' => array(
	'table' => 'Patients', // Name of linked table
	    'fields' => array('Name'), // Name of linked fields to search in
	    'display_fields' => array('Id','Name','Age'), // Which fields to show in dropdown box
	    'fillup_field' => 'Name', // Which field to fill up this table with
	    'primary_key' => 'Id', // Primary key of the linked table
            'display_in_table_field' => null)
);
$opts['input_suggestions'] = array( // Suggestions which appear next to input boxes
    'Id' => 'Auto generated',
    'Name' => 'Check whether the patient exists!'
);
$opts['input_validations'] = array( // Validations - 'character', 'numeric', 'capital', 'required'
    'Name' => array('character','capital','required')
);
$opts['invisible']=array(); // Invisible fields
$opts['filter']= ''; // The WHERE clause, i.e. "Name REGEXP 'ss'"

// Do not edit below this
$_SESSION['opts']=$opts;
require_once('phpMyTable.class.php');
$pmt = new phpMyTable($opts);
?>
<p>For queries, <a href="mailto:cmacus@gmail.com">mail me</a>.</p>
</body></html>
