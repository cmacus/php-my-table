<?php
class phpMyTable
{
    /* Generates a HTML editable table interface from a mysql table, given $opts as argument */
    public $mysqli, $search_array;
    
	public function create_dual_text_box($value,$display,$attrs,$max_length)
	{
		// Create a text box with value, and a label with the display value, of max_length; the atttrs will be added
	    echo '<div class="dual_text_box">
	    <input class="dual_text_box_value ',$attrs,' value="',$value,'"></input>
		<span class="dual_text_box_display" title="',$display,'">';
		if (strlen($display) > $max_length)
			echo substr($display,0,$max_length-3).'...';
		else
			echo $display;
		echo '</span>
		</div>';
	}
	
	public function connect_and_execute()
	{}
	
    public function phpMyTable($opts)
    {
		require('constants.php');
		global $mysqli, $TEXT_FIELD_TYPE, $TIMESTAMP_FIELD_TYPE, $DATETIME_FIELD_TYPE, $DATE_FORMAT, $MAX_LENGTH_DISPLAY_FIELD_IN_DUAL_TEXT_BOX;
		$mysqli = new mysqli($opts['host'],$opts['username'],$opts['password'],$opts['db']);
		if (!$mysqli) die('You have probably been logged out. <a href="index.php?error">Login again</a>.');
		if (isset($_POST[$primary_key]))// Update the row with primary key from POST
		    $opts['data_array']=$_POST;
		$current_table = $opts['table'];
		$current_primary_key = $opts['primary_key'];
	
		// Reset function
		if (array_key_exists('reset',$_GET)) // Clear and sort and search information
		{
		    unset($_SESSION['sort_sql'],$_SESSION['search_sql'],$_SESSION['sort'],$_SESSION['selected_items']);
		}
	
		// Global update
		if ($_SESSION['selected_items'])
		{
		    if (count($_SESSION['selected_items']) > 0) // If some items were checked
		    {
				extract($_POST);
				extract($opts);
				global $mysqli;
				foreach ($_SESSION['selected_items'] as $key => $value)
				{
				    if (isset($value))
					$res = $mysqli->query("UPDATE `$table` SET `$global_update_field` ='$global_update_value' WHERE `$primary_key` = '$key'");
				    if (!$res) echo $mysqli->error;
				}
				unset($_SESSION['selected_items']);
		    }
		}
		
		// Search function
		if (array_key_exists('search',$_GET))
		{
		    $opts['search']=array_slice($_GET,1);
		    $table=$current_table;
		    unset($_SESSION['page_number']);
		    $search_sql=$_SESSION['search_sql'];
		    global $search_array;
		    foreach($opts['search'] as $key => $value)
		    {
				if ($value) // Filter only fields that are being searched for
				    $search_array[$key] = $value;
		    }
		    if (!count($search_array)) 
		    {
				unset($_SESSION['search_sql']);
				return;
		    }
	    
		    $search_sql = " ";
		    $search_field_count = count($search_array);
		    $i=1;
		    foreach ($search_array as $key => $value)
		    {
				if (array_key_exists($key,$refs)) // If it is a reference field do an exact search
				    $search_sql .= " `$key` = '$value' ";
				else
				    $search_sql .= " `$key` REGEXP '$value' ";
				if ($i != $search_field_count)
				    $search_sql .= " AND ";
				$i++;
		    }
		    $_SESSION['search_sql'] = $search_sql;
		}
	
		// Store the details of the present page
		echo '<div id="page_details">';
		foreach($opts as $key=>$value)
		{
		    echo '<span id="',$key,'">',$value,'</span>';
		}
		echo '</div>';
	
	
		echo '<div id="current_table" style="display:none">',$current_table,'</div>';
		
		// Initiate connection
	
		global $mysqli, $TEXT_FIELD_TYPE, $DATETIME_FIELD_TYPE, $TIMESTAMP_FIELD_TYPE;
	
		// Start building sql
		$sql = "SELECT * FROM `".$opts['table']."`";
	
		// Search & filter
		if ($_SESSION['search_sql'])
		    if ($opts['filter'])
				$sql .= " WHERE ".$_SESSION['search_sql']." AND ".$opts['filter'];
			else
			    $sql .= " WHERE ".$_SESSION['search_sql'];
		else
		    if (isset($opts['$filter']))
				$sql .= " WHERE ".$opts['filter'];
	
		// Sort
		if (isset($_GET['sort']))
		{
		    $sort_key=$_GET['sort'];
		    if ($_SESSION['sort'][$sort_key]) // Sort on this field exists
		    {
				if ($_SESSION['sort'][$sort_key] == 'ASC')
				    $_SESSION['sort'][$sort_key] = 'DESC'; // Reverse it
				else
				    $_SESSION['sort'][$sort_key] = 'ASC'; // Reverse it
		    }
		    else
				$_SESSION['sort'][$sort_key] = 'ASC';
		    if ($_SESSION['sort'])
		    {
				$sort_sql = " ORDER BY ";
				$sort_field_count = count($_SESSION['sort']);
				$i=1;
				foreach($_SESSION['sort'] as $sort_field => $direction)
				{
				    $sort_sql .= "`$sort_field` $direction";
				    if ($i == $sort_field_count)
						$sort_sql .= " ";
				    else
						$sort_sql .= ", ";
				    $i++;
				}
				$_SESSION['sort_sql'] = $sort_sql;
		    }	
		    if ($_SESSION['sort_sql']) // If user has clicked on a sort field before
		    {
				$sql .= $_SESSION['sort_sql'];
		    }
		    elseif (count($opts['sort'])) // If this is the first time page is loading
			{
				$sql .= " ORDER BY ";
				foreach ($opts['sort'] as $key=>$value)
				{
				    $sql .= " `$key` $value,";
				}
				$sql = substr($sql,0,-1); // Remove trailing comma
			}
		}
	
	// Custom query - disabled
	
		// Pagination
		$res = $mysqli->query("SELECT COUNT(*) FROM ($sql) AS Count");
		if (!$res) echo $mysqli->error;
			$row = $res->fetch_row();
		$number_of_results = $row[0];
	
		//Determine results per page
		if (isset($_POST['results_per_page']))
		{	  
		    $_SESSION['results_per_page'] = $_POST['results_per_page'];
		}
		$results_per_page = $_SESSION['results_per_page']?$_SESSION['results_per_page']:10;
	
		$number_of_pages = ceil($number_of_results/$results_per_page);
	
		if (isset($_GET['page_number'])) // Previously clicked by a page link
		{
			$_SESSION['page_number'] = $_GET['page_number'];
		}
	
		if ($_SESSION['page_number'])
		{
		    extract($_SESSION);
		}
		else
		{
		    if ($number_of_pages == 0)
			$page_number=0;
		    else $page_number=1;
		}
	
		echo '<div class="paginate">';
		echo 'Show <form id="results_per_page_form" method="POST" action="',$_SERVER['PHP_SELF'],'"><input type="text" value="',$results_per_page,'" name="results_per_page"/> results per page. </form>';
		echo '<strong>',$number_of_results,'</strong> Records. Page ', $page_number, ' of ', $number_of_pages, ' ';
		echo ($page_number == 1) ? ' ' : '<a href="'.$_SERVER['PHP_SELF'].'?page_number='.($page_number-1).'"><span class="page_link"><img src="images/prev.png"/></span></a>';
		echo ' <select name="page_numbers" class="page_numbers">',
	    '<option value="" selected>Go to</option>';
		for ($i=1;$i<=$number_of_pages;$i++)
		{
		    echo '<option value="',$i,'">',$i,'</option>';
		}
		echo '</select> ';
		echo ($page_number == $number_of_pages) ? ' ' : ' <a href="'.$_SERVER['PHP_SELF'].'?page_number='.($page_number+1).'"><span class="page_link"><img src="images/next.png"></span></a> ';
	
		echo ' <a class="new_button" id="new_button_',$table,'" href="javascript:void(0)"><span class="new_button" id="new_button_top_"',$table,'"><img src="images/new.png" alt="New record"></span></a> <span class="reset_button"><a href="',$_SERVER['PHP_SELF'],'?reset=1"><img src="images/reset.png"/></a></span> ';
		echo '</div>';
		$low_limit = ($page_number-1) * $results_per_page;
		if (!$page_number) $low_limit=1;
			$sql .= " LIMIT $low_limit, $results_per_page ";
	
		// If a primary key has already been received by a GET request, fetch that record only
		if (isset($_GET[$opts['$primary_key']]))
		{
		    $key = $_GET[$opts['primary_key']];
		    $sql = "SELECT * FROM `".$opts['table']."` WHERE `".$opts['$primary_key']."` = '$key'";
		}
	
		// Get table data
		$data_results = $mysqli->query($sql);
		if (!$data_results)
		{
		    echo $mysqli->error;
		}

		$fields = $data_results->fetch_fields();
		$row = $data_results->fetch_row();
	
		// Determine position of primary key
		for($i=0;$i<count($fields);$i++)
		{
		    if ($fields[$i]->name == $opts['primary_key'])
				$position_of_primary_key = $i;
		}
	
		// The 'show' div
		echo<<<END
		<div class="show">
		<a href="javascript:void(0)"><div class="close_button" id="close_show_button"><img src="images/close.png" alt="Close" title="Close"></div></a>
		<div class="content"></div>
		</div>
END;
	  
		// The new record form
		echo '<div class="new" style="';

		if (array_key_exists('new',$_GET)) // If 'new' is there in the URL
			echo 'display:block';
		else //Hide it
			echo 'display:none';
		echo '">';
		echo '<div class="close_button"><a href="',$_SERVER['PHP_SELF'],'"><img src="images/close.png"></a></div>
		<form name="new_record_form" id="new_record_form" method="POST" action="write.php">';
		$i = 0; 
	
		// Name of current table
		echo '<input type="hidden" name="current_table" value="',$current_table,'"/>';
		
		for ($i=0;$i<count($fields);$i++)
		{
	    
		    echo '<div class="field ', $fields[$i]->name,'">'; // The div containing the entry
		    echo '<div class="new_label"><label class="',$fields[$i]->name,' '; // The label for the entry
		    if ($opts['primary_key']==$fields[$i]->name)
				echo $opts['$primary_key']; // If this field is primary key, add it to the class of the label
			echo '">',$fields[$i]->name,'</label></div>';
	    
			echo '<div class="new_value">'; // The div containing the input/select box
			if (array_key_exists($fields[$i]->name,$opts['defaults'])) // If this field has a default value supplied by $opts
			{
				if (is_array($opts['defaults'][$fields[$i]->name]))
				{
					$def_this_field = $opts['defaults'][$fields[$i]->name];
					$def_table = $def_this_field['table'];
					$def_field = $def_this_field['field'];
					$def_foreign_key = $def_this_field['foreign_key'];
					$def_value = $def_this_field['value'];
					if ($def_table && $def_foreign_key && $def_value)
					{
					    $sql = "SELECT `$def_field` FROM `$def_table` WHERE `$def_foreign_key` = '$def_value'";
					    $def_res=$mysqli->query($sql);
					    $def_row = $def_res->fetch_row(); // Fetch the default value from the parameters
					}
				}
				else
					$def_value = $opts['defaults'][$fields[$i]];
			}
	    
			// Construct the type of input box
			if ($fields[$i]->type == $TEXT_FIELD_TYPE) // Text field
				echo '<textarea ';
			else if (array_key_exists($fields[$i]->name,$opts['refs'])) // This field is a reference
				echo '<select ';
			else
				echo '<input type="text" ';
	    
			// Construct the attributes of the input box
			echo 'title="', $fields[$i]->name ,'" ', // The title
			'name="',$fields[$i]->name,'" ', // Name for form purpose
			'placeholder="',$fields[$i]->name,'" ',// Placeholder value
		
			// Class attribute begins
			'class="field ',$fields[$i]->name; // Class - includes 'field', the name of the field
	    
			if ($opts['primary_key'] == $fields[$i]->name) // If this is the primary key, add it to class
				echo ' primary_key';
			if ($fields[$i]->type == $DATETIME_FIELD_TYPE || $fields[$i]->type == $TIMESTAMP_FIELD_TYPE) // Date time field, add a class to attach the calendar later
				echo ' date_field ';
			if (isset($opts['input_validations'][$fields[$i]->name]))
			{
				foreach($opts['input_validations'][$fields[$i]->name] as $validation_key=>$validation_value)
				{
					echo ' '.$validation_value; // Whether numeric, character, email
				}
			}
			echo '" '; // Class attribute ends
	    
			if (isset($opts['input_max_lengths'][$fields[$i]->name]))
			{
				echo ' maxlength="',$input_max_lengths[$fields[$i]->name],'"';
			}
			echo ' id="';
			//if ($opts['dropdown'][$fields[$i]->name]) // This fields needs a dropdown box, needs dropdown.js
			//	echo $fields[$i]->name,'_dropdown'; // Add a '_dropdown' after its id
			//else
			echo $fields[$i]->name;
			echo '" '; // Id attribute ends
		
			if (in_array($fields[$i]->name, $opts['readonly_fields']))
				echo 'readonly="true" ';
		
			if (isset($opts['input_suggestions'][$fields[$i]->name]))
				echo 'suggestion="',$opts['input_suggestions'][$fields[$i]->name],'" ';
			echo 'value="';
			if (array_key_exists('new',$_GET) && isset($_GET[$fields[$i]->name])) // If the address bar has given the 'new' parameter and default value for a field
			{
				echo $_GET[$fields[$i]->name];
			}
			if (isset($opts['defaults'][$fields[$i]->name]))// If this has a default value set by $opts parameters
			{
				echo ($def_row) ? $def_row[0] : $opts['defaults'][$fields[$i]->name];
			}
			echo '">';

			if ($fields[$i]->type == $TEXT_FIELD_TYPE) // This is a text field
			{
				echo ($def_row) ? $def_row[0] : "";
				echo '</textarea></div>';
			}
		
			elseif ($opts['refs'][$fields[$i]->name]) // This is a reference
			{
				$ref = $opts['refs'][$fields[$i]->name]; // Construct the select box from parameters supplied by foreign key, table and display field
				if ($ref['foreign_key'])
				{
				    $ref_sql = "SELECT ". $ref['foreign_key'] . ", " . $ref['display_field'] . " FROM " . $ref['table'];
					if (isset($ref['order']))
						$ref_sql.=" ORDER BY ".$ref['display_field']." ".$ref['order'];
				
					$ref_results=$mysqli->query($ref_sql);
					echo '<option value=""></option>';
					while($ref_row=$ref_results->fetch_assoc())
					{
						echo '<option value="',$ref_row[$ref['foreign_key']],'"';
						if (isset($_GET[$fields[$i]->name])) // If the address bar has given the value for a field
						{
							if ($_GET[$fields[$i]->name] == $ref_row[$ref['foreign_key']])
							echo ' selected ';
						}
						if (isset($opts['defaults'][$fields[$i]->name]))
						{
							if ($def_value == $ref_row[$ref['foreign_key']])
						    echo ' selected ';
						}
						echo '>',$ref_row[$ref['display_field']],'</option>';
					}
					echo '</select></div>';
				}
		
				else // For enum fields specified in $opts['refs'], which have no table associated
				{
				    foreach ($ref as $val)
				    {
						echo '<option value="',$val,'"';
					if (isset($_GET[$fields[$i]->name]) &&  $_GET[$fields[$i]->name] == $val)
					    echo ' selected ';
					if (isset($opts['defaults'][$fields[$i]->name]))
					{
					    if ($def_value == $val)
						echo ' selected ';
					}
					echo '>',$val,'</option>';
				}
				echo '</select></div>';	
			}
		}
	
		else
			echo '</input></div>';
		echo '</div>';
		unset($def_row);
	}

	echo '<div id="multiple_entry_buttons">'; // Construct entry for multiple foreign_key fields
	foreach($opts['multiple_refs'] as $ref)
	{
		echo<<<END
			<a class="fancy_button" href="javascript:void(0)"
			onclick="open_multiple_entry_table('{$ref['table']}','{$ref['foreign_key']}',
			'{$ref['primary_key']}')">
			Add from {$ref['table']}</a>
END;
	}
	echo '</div>';
	
	echo '<input type="submit" value=" Add "></input></form><div>Inserted row id <label id="row_id"/></div></div>';
	
	// Set up dropdown function; needs dropdown.js included in headers
	echo "<script type='text/javascript'><!--";
	
	foreach($opts['dropdown'] as $dropdown_field=>$dropdown_field_details)
	{
		
		echo "
		var details = new Array();
		details['{$dropdown_field}'] = new Array();";
		if ($dropdown_field_details['db'] == null)
			echo "details['{$dropdown_field}']['db'] = '{$opts['db']}'";
		else
			echo "details['{$dropdown_field}']['db'] = '{$dropdown_field_details['db']}'";
		echo "
			details['{$dropdown_field}']['table'] = '{$dropdown_field_details['table']}';
			details['{$dropdown_field}']['keyfields'] = new Array();
			";
		$i=0;
		foreach($dropdown_field_details['fields'] as $dropdown_keyfield)
		{
			echo "
			details['{$dropdown_field}']['keyfields'][{$i}] = '{$dropdown_keyfield}';
			";
			$i++;
		}
		echo "
			details['{$dropdown_field}']['fields'] = new Array();
			";
		$i=0;
		$primary_key_included = 0;
		foreach($dropdown_field_details['display_fields'] as $dropdown_display_field)
		{
			if ($dropdown_display_field == $dropdown_field_details['primary_key'])
			{
				$primary_key_included = 1;
					break;
			}
		}
		if (!$primary_key_included)
		{
			echo "details['{$dropdown_field}']['fields'][{$i}] = '{$dropdown_field_details['primary_key']}';";
			$i++;
		}
		
		foreach($dropdown_field_details['display_fields'] as $dropdown_display_field)
		{
		echo "
			details['{$dropdown_field}']['fields'][{$i}] = '{$dropdown_display_field}';
			";
			$i++;
		}
		
		echo "
			details['{$dropdown_field}']['username'] = '{$opts['username']}';
			details['{$dropdown_field}']['password'] = '{$opts['password']}';
			details['{$dropdown_field}']['host'] = '{$host}';
			details['{$dropdown_field}']['textbox'] = '{$dropdown_field}';
			details['{$dropdown_field}']['fillup'] = 'fillup';
			details['{$dropdown_field}']['fillup_field'] = '{$dropdown_field_details['fillup_field']}';
			details['{$dropdown_field}']['primarykey']='{$dropdown_field_details['primary_key']}';
			details['{$dropdown_field}']['onclick'] =\"$('#{$dropdown_field}').val('fillup_field')\";
			// What happens on clicking it, primarykey is replaceable;
			dropdown_box(details['{$dropdown_field}']);
			";
				
	}
	echo "
	  function fill_dropdown_field(host,db,table,dropdown_box, keyfield, primarykey,fillup_field)
		{
		$.get('get-dropdown-data.php',{
			key:primarykey,
			keyfield: keyfield,
			host: host,
			db: db,
			table:table,
			fillup_field: fillup_field
			},
			function(data)
			{
				$(\"#\"+dropdown_box).val(data);
			});
		}
		--></script>";
	
	// Begin table	  
	echo '<table id="results">';
	
	// Count relative width
	foreach($opts['relative_width'] as $key=>$value)
		$sum += $value;
	
	// Columns
	foreach ($fields as $field)
	{
		echo '<col id="',
		$field->name,'" ';	
		if (isset($opts['relative_width'][$field->name]))
			{
				$width_percent = floor($opts['relative_width'][$field->name] * 100/ $sum);
				echo 'style="width:',$width_percent,'%"';
			}
		echo '>';
	}
	
	// Header row
	echo '<thead><tr><th></th>';
	
	foreach($fields as $field)
	{
		if (!in_array($field->name,$opts['invisible']))
		{		
			echo '<th scope="col" title="Sort on this field" class="',$field->name;
			if ($field->name == $opts['primary_key']) echo " primary_key ";
			echo '" ';
			if (isset($opts['relative_width'][$field->name]))
			{
				$width_percent = floor($opts['relative_width'][$field->name] * 100/ $sum);
				echo 'style="width:',$width_percent,'%"';
			}
			echo '><a href="',
			$_SERVER['PHP_SELF'],
			'?sort=',
			$field->name,
			'">';
			if (isset($opts['max_col_header_length']))
				if (strlen($field->name) > $opts['max_col_header_length'])
						echo substr($field->name,0,$opts['max_col_header_length']-3).'...';
				else
					echo $field->name;
			else
				echo $field->name;
			'</a></th>';
			
		}
	}		    
	echo '<th/>';
	
	echo '</tr></thead>';
	
	// Body of table
	echo '<tbody>';
	
	// Search row
	echo '<tr class="search"><form class="search_form" action="',$_SERVER['PHP_SELF'],'" method="GET">
		<input type="hidden" name="search" value="1">';
	global $search_array;
	echo '<td><input type="checkbox" id="select_all"></input></td>';
	for ($i=0;$i<count($fields);$i++)
	{
		if (!in_array($fields[$i]->name,$opts['invisible']))
		{
			echo '<td>';
			if (isset($opts['refs'][$fields[$i]->name]))
				echo '<select ';
			else
				echo '<input type="text" ';    
			echo 'class="search ';
			if ($fields[$i]->type == $DATETIME_FIELD_TYPE || $fields[$i]->type == $TIMESTAMP_FIELD_TYPE)
				echo ' date_field ';
			echo  $fields[$i]->name,
				'" name="',
				$fields[$i]->name,
				'" placeholder="Search by ',
				$fields[$i]->name,
				'" id="search_',
				$fields[$i]->name,	
				'" value="',
				$search_array[$fields[$i]->name],
				'">';
			
			
			if (isset($opts['refs'][$fields[$i]->name]))
			{
				$ref = $opts['refs'][$fields[$i]->name];
				if ($ref['foreign_key'])
				{
					$ref_sql = "SELECT ". $ref['foreign_key'] . ", " . $ref['display_field'] . " FROM " . $ref['table'];
					$ref_results=$mysqli->query($ref_sql);
					echo '<option value=""></option>';
					while($ref_row=$ref_results->fetch_assoc())
					{
						if ($search_array[$fields[$i]->name] == $ref_row[$ref['foreign_key']])
							echo '<option selected ';
						else
							echo '<option ';
						echo ' value="',$ref_row[$ref['foreign_key']],'">',
							(isset($ref['max_display_length']) && strlen($ref_row[$ref['display_field']]) > $ref['max_display_length']) ? substr($ref_row[$ref['display_field']],0,$ref['max_display_length']).'...'
							: $ref_row[$ref['display_field']],
							'</option>';
					}
					echo '</select>';
				}
				else
				{
					echo '<option value=""></option>';
						foreach ($ref as $val)
						{
							echo '<option value="',$val,'">',$val,'</option>';
						}
				}
			}
			else
				echo '</input>';
			echo '</td>';
		}
		
	}
	
	echo '<td><input type="submit" alt="Search" value="Search" id="search_button"></input></td>';
	echo '</form>';
	echo '</tr>';
	
	// Begin main body
	$rowcount=0;
	$colcount=0;
	while ($row)
	{
		
		$rowcount++;
		echo '<tr class="result" id="',$row[$position_of_primary_key],'"><form action="update.php" method="POST" class="update_form">';
		echo '<input type="hidden" name="current_table" value="',$current_table,'"/>';
		echo '<input type="hidden" name="current_primary_key" value="',$current_primary_key,'"/>';	
		echo '<td><input type="checkbox" class="selected"></input></td>';
		$i = 0; 
		for ($i=0;$i<count($fields);$i++)
		{
			// Construct the attributes of the box first
			
			// Class attribute begins
			$attrs = ' class="field ';
			if ($fields[$i]->type == $DATETIME_FIELD_TYPE || $fields[$i]->type == $TIMESTAMP_FIELD_TYPE)
				$attrs.= 'date_field ';
			if (isset($opts['click_fields'][$fields[$i]->name]))
				$attrs.= 'click_field ';
			$attrs.= $fields[$i]->name.'"';
			// Class attribute ends
	
			if (isset($opts['click_fields'][$fields[$i]->name]))
			{
				$attrs.= ' click_table_page="'.$opts['click_fields'][$fields[$i]->name]['click_table_page'].'" ';
				$attrs.= ' click_primary_key="'.$opts['click_fields'][$fields[$i]->name]['click_primary_key'].'"';
			}
			
			// Placeholder attribute begins
			$attrs.= ' placeholder="'.$fields[$i]->name;
			// Placeholder attribute ends
			
			// Id attribute begins
			$attrs.= '"id="field_box_'.$rowcount."_".$colcount;
			// Id attribute ends
			
			if ($opts['readonly']) 
			$attrs.= ' readonly ';
			
			// Name attribute begins
			$attrs.='" name="'.$fields[$i]->name.'"';
			// Name attribute ends
			
			// Style attribute begins
			if(isset($opts['relative_width'][$fields[$i]->name]))
			{
				foreach($opts['relative_width'][$fields[$i]->name] as $key=>$value)
					$sum+=$value;
			}
			// Style attribute ends
			
			// Title attribute begins
			$attrs.= 'title="'.$fields[$i]->name.': '.$row[$i].'" ';
			// Title attribute ends
						
			if (!in_array($fields[$i]->name,$opts['invisible'])) // If this field is not set invisible
			{
			  echo '<td class="field_cell ', $fields[$i]->name, '">';
			  $colcount++;
			  if (isset($opts['refs'][$fields[$i]->name]))
			  {
			    if (isset($opts['refs'][$fields[$i]->name]['table']))
			      {
				extract($opts['refs'][$fields[$i]->name]);
				$ref_res = $mysqli->query("SELECT `{$display_field}` FROM `{$table}` WHERE `{$foreign_key}` = '{$row[$i]}'");
				$row_ref = $ref_res->fetch_row();
				if ($row_ref[0])
				  $this::create_dual_text_box($row[$i],$row_ref[0],$attrs,$opts['refs'][$fields[$i]->name]['max_display_length']);
			      }
			    else
			      echo '<input type="text" ',$attrs,' value="',$row[$i],'"></input>';
			  }
		    elseif (isset($opts['dropdown'][$fields[$i]->name])) // This field is a dropdown
		    {
			if ($opts['dropdown'][$fields[$i]->name]['display_in_table_field'])
			{
			    $sql_ref = "SELECT `{$opts['dropdown'][$fields[$i]->name]['display_in_table_field']}`
FROM `{$opts['dropdown'][$fields[$i]->name]['table']}`
WHERE `{$opts['dropdown'][$fields[$i]->name]['fillup_field']}` = '{$row[$i]}'";
			    
			    $ref_res = $mysqli->query($sql_ref);
			    if ($ref_res) $row_ref = $ref_res->fetch_row();
			    if ($row_ref[0])
				$this::create_dual_text_box($row[$i],$row_ref[0],$attrs,$opts['dropdown'][$fields[$i]->name]['max_display_length']);
			    else
				echo '<input type="text" ',$attrs,' value="',$row[$i],'"></input>';
			}
			else
			    echo '<input type="text" ',$attrs,' value="',$row[$i],'"></input>';
		    }
		    else
		    {
					if ($fields[$i]->type == $TEXT_FIELD_TYPE) // Text field
						echo '<textarea ',$attrs,'>';
					else
						echo '<input type="text"',$attrs,' value="',$row[$i],'">';
					if ($fields[$i]->type == $TEXT_FIELD_TYPE)
						echo $row[$i],'</textarea>';
					else
						echo '</input>';
				}
				echo '</td>';
			}
		}

		echo '<td>
		
		<span class="action_buttons">
		<input type="Submit" value="Update" class="update_button"></input></form> 
		<a href="javascript:void(0)" class="edit_button"><img src="images/edit.png" alt="Edit"></a> 
		<a href="javascript:void(0)" class="print_button"><img src="images/print.png" alt="Print"></a> 
		<a href="javascript:void(0)" class="show_button"><img src="images/show.png" alt="Show"></a> 
		<a href="javascript:void(0)" class="copy_button"><img src="images/copy.png" alt="Copy"></a> 
		<a href="javascript:void(0)" class="delete_button"><img src="images/delete.png" alt="Delete"></a>
		</span></td>';
		
		// Build the show box but keep it hidden
		echo '</tr>';
		$colcount=0;
		$row = $data_results->fetch_row();
	}
	echo '</tbody></table></div>';
	
	echo '<div id="global_update"><h3>Global updates</h3>';
	echo '<form name="global_update" id="global_update_form" action="',$_SERVER['PHP_SELF'],'" method="POST">
		Set <select name="global_update_field">';
	foreach($fields as $field)
	{
		echo '<option value="',$field->name,'">',$field->name,'</option>';
	}
	echo '</select> as <input name="global_update_value"></input><a href="javascript:void(0)">
		<img id="global_update_form_submit" src="images/yes.png" alt="Go"/></a> in checked items</form></div>';  
	}	  
}
?>
