<?php
session_start();
extract($_SESSION);
extract($opts);
extract($_POST);
extract($_GET);

$table = $current_table;
$primary_key = $current_primary_key;

if (array_key_exists('readonly',$opts))
	if ($readonly) die("Table is read only!");

$mysqli = new mysqli($host,$username,$password,$db);
$sql = "UPDATE `$table` SET ";
foreach($_POST as $key => $value)
{
    if ($key != 'current_table' && $key != 'current_primary_key')
    {
	if ($key != $primary_key)
	{
	    $value=addslashes($value);
	    $sql .= "`$key`='$value',";	
	}
    }
}
$sql = substr($sql,0,-1);
$sql .= " WHERE `$primary_key` = '$_POST[$primary_key]'";

$res=$mysqli->query($sql);
echo ($res) ? "Result updated" : $sql.": ".$mysqli->error;
?>
