<?php
echo file_get_contents("DATE_FORMAT");
?>
