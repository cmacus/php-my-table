<?php
global $TEXT_FIELD_TYPE ;
global $TIMESTAMP_FIELD_TYPE ;
global $DATETIME_FIELD_TYPE ;
global $HEMAT_DIVISION;
global $BIOCHEM_DIVISION;
global $DATE_FORMAT ;

$TEXT_FIELD_TYPE = 252; // 252, i.e. field type of text, to make a textarea
$TIMESTAMP_FIELD_TYPE = 7; // 7
$DATETIME_FIELD_TYPE = 12;
$HEMAT_DIVISION=0;
$HEMAT_DIVISION_TESTS_BEGIN=0;
$HEMAT_DIVISION_TESTS_END=499;
$BIOCHEM_DIVISION=500;
$DATE_FORMAT = file_get_contents("DATE_FORMAT");
$HEMAT_ROW_TEST_BEGINS = 19;
$HEMAT_ROW_TEST_ENDS = 20;
$BIOCHEM_ROW_TEST_BEGINS = 11   ;
$BIOCHEM_ROW_TEST_ENDS = 34;

global $uploaddir;
$uploaddir="shared-files/";

global $host;
$host="localhost";
global $db;
$db="Pap_study";
?>
