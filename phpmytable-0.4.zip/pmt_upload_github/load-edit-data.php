<?php
session_start();
extract($_SESSION);
extract($opts);
extract($_GET);
header('Content-Type: text/plain');
// Load chosen record into the 'edit' form
$mysqli =new mysqli($host,$username,$password,$db);

$sql = "SELECT * FROM `$table` WHERE `$primary_key` = '$pk'";
$res = $mysqli->query($sql);
$row = $res->fetch_assoc();
$fields = $res->fetch_fields();
echo "{\n";
$i = 0;
foreach($row as $key => $value)
{
	$i++;
	echo "\"$key\"", " : ", "\"$value\"";
	if (count($fields) != $i)
	   echo ",";
	echo "\n";
}
echo "}";
?>
