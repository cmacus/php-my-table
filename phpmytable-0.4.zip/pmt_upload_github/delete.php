<?php
session_start();
extract($_SESSION);
extract($_GET);
extract($opts);
$mysqli = new mysqli($host,$username,$password,$db);
$res = $mysqli->query("DELETE FROM `$table` WHERE `$primary_key` = '$pk'");
echo ($res) ? "0" : $mysqli->error;
?>
