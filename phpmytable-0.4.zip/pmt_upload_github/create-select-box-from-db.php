<?php
function create_select_box_from_db($host,$db,$username,$password,$table,$field,$value_field,$select_box_id, $select_box_name,$select_box_class)
{
    $mysqli = new mysqli($host,$username,$password,$db);
    $res = $mysqli->query("SELECT $value_field, $field FROM $table");
    if (!$res) die($mysqli->error);
    echo '<select name="',$select_box_id,'" class="',$select_box_class,'" id="',$select_box_id,'" name="',$select_box_name,'">';
    while ($row = $res->fetch_assoc())
    {
        echo '<option value="',$row[$value_field],'">',$row[$field],'</option>';
    }
    echo '</select>';
}
?>