<?php
session_start();
?>
<html>
<head>
<link rel="stylesheet" href="styles/phpMyTable.css"/>
<script type="text/javascript" src="scripts/jquery.js"></script>
<script type="text/javascript" src="scripts/phpMyTable.js"></script>
<style type="text/css">@import url(jscalendar/calendar-mac.css);</style>
<script type="text/javascript" src="jscalendar/calendar.js"></script>
<script type="text/javascript" src="jscalendar/lang/calendar-en.js"></script>
<script type="text/javascript" src="jscalendar/calendar-setup.js"></script>
<title>Copy</title>
</head>

<body>
<div class="notice"></div>
<?php
require_once('constants.php');

extract($_SESSION);
extract($_GET);
extract($opts);
$mysqli = new mysqli($host,$username,$password,$db);
$sql = "SELECT * FROM `$table` WHERE `$primary_key` = '$pk'";
$res=$mysqli->query($sql);
$row=$res->fetch_row();
$fields=$res->fetch_fields();
echo '<div class="copy"><div class="close_button"><a href="javascript:window.close();"><img src="images/close.png" alt="Close" title="Close"></a></div><div id="current_table">',$current_table,'</div>
<form name="copy_record_form" id="copy_record_form" method="POST">';
$i = 0; 
for ($i=0;$i<count($fields);$i++)
    {
	echo '<div class="field ', $fields[$i]->name, '">';
	echo '<div class="new_label"><label>',
	    $fields[$i]->name,
	    '</label></div>';
	echo '<div class="new_value">';

	if ($fields[$i]->type == $TEXT_FIELD_TYPE) // Text field
	    echo '<textarea rows="5" cols="10"';
	elseif ($opts['refs'][$fields[$i]->name]) // This field is a reference
	    echo '<select ';
	else
	    echo '<input type="text" value="',
		$row[$i],
		'" ';
	echo 'title="',
	    $fields[$i]->name,
	    '" name="',
	    $fields[$i]->name,
	    '" id="',
	    $fields[$i]->name,
	    '" class="',
	    $fields[$i]->name,
	    '">';
	if ($fields[$i]->type == $TEXT_FIELD_TYPE)
	    echo $row[$i],'</textarea></div>';
	elseif ($opts['refs'][$fields[$i]->name])
	    {
		$ref = $opts['refs'][$fields[$i]->name];
		if ($ref['foreign_key'])
		    {
			$ref_sql = "SELECT ". $ref['foreign_key'] . ", " . $ref['display_field'] . " FROM " . $ref['table'];
			$ref_results=$mysqli->query($ref_sql);
			echo '<option value=""></option>';
			while($ref_row=$ref_results->fetch_assoc())
			    {
				if ($row[$i] == $ref_row[$ref['foreign_key']])
				    echo '<option selected value="',$ref_row[$ref['foreign_key']],'">',$ref_row[$ref['display_field']],'</option>';
				else
				    echo '<option value="',$ref_row[$ref['foreign_key']],'">',$ref_row[$ref['display_field']],'</option>';
			    }
		    }
		else
		    {
			foreach ($ref as $val)
			    {
				echo '<option value="',$val,'">',$val,'</option>';
			    }
		    }
		echo '</select></div>';
	    }
	else
	    echo '</input></div>';
	echo '</div>';
    }
echo '<input type="image" src="images/yes.png" alt="Make copy" id="Copy"></input></form>';
?>
</div></body></html>
