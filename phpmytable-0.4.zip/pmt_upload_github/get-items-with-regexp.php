<?php
session_start();
extract($_SESSION);
extract($opts);
extract($_GET);
$mysqli = new mysqli($host, $username, $password, $db);
$res = $mysqli->query("SELECT `PVMS`, `Nomenclature` FROM Items WHERE `Nomenclature` REGEXP '$regexp'");
echo '<ul>';
while ($row = $res->fetch_assoc())
{
	extract($row);
	echo '<li id="',$PVMS,'"><a href="javascript:void(0)">',$PVMS,'-',$Nomenclature,'</a></li>';
}
echo '</ul>';
?>