<?php
session_start();
extract($_SESSION);
extract($opts);
extract($_POST);
$mysqli = new mysqli($host,$username,$password,$db);
?>
