<?php
extract($_POST);
$SELECTED_ITEM_BGCOLOR = "#efabab";
$mysqli = new mysqli($host,$username,$password,$db);
$sql = "SELECT ";
foreach($fields as $field)
{
    $sql .= " `{$field}`,";
}
$sql = substr($sql, 0, -1);
$sql .= " FROM `{$table}` WHERE ";

foreach($keyfields as $keyfield)
{
    $sql .= "`{$keyfield}` REGEXP '{$key}' OR ";
}
$sql = substr($sql,0, -4); // Remove the last OR

$res = $mysqli->query($sql);

if (!$res->num_rows && strlen($key) > 5) die("No match");

$str_before_text = $str_text = $str_after_text =null;

if ($res->num_rows) echo "<ul>"; else die();
while($row = $res->fetch_assoc())
{
    
    $str_before_text = '<li ';
    if ($onclick!=null)
        $str_before_text .= 'onclick="'.str_replace("primary_key",$row[$primarykey],str_replace("fillup_field",$row[$fillup_field],$onclick)).'">';
    else
        $str_before_text .= '>';
    $str_before_text .= '<a href="javascript:void(0);">';
    $str_text = null;
    foreach($fields as $field)
    {
        $str_text .= $row[$field]." ";
    }
    $str_text = substr($str_text,0,-1);
    
    $str_text = preg_replace("/(?i)$key/","<strong>$0</strong>",$str_text); // Make the matched string bold
    $str_after_text = '</a></li>';
    echo $str_before_text.$str_text.$str_after_text;
}
echo "</ul>";
