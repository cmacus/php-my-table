// Dropdown.js
// Attach a text box to a field in a database, so that regexp search is possible
// Requires jQuery, PHP

MIN_KEY_LENGTH=2
MAX_KEY_LENGTH=15
UP_KEY=38;
DOWN_KEY=40;
ENTER_KEY=13;
TAB_KEY=9;
ESCAPE_KEY=27;
var focused_at = 0;

function dropdown_box(details) // Details is an array holding all the data
{
    
    textbox = details['textbox'];
    if (details['multiple']==1) // A class of textboxes
        selector = '.'+textbox;
    else
        selector = 'input#'+textbox; // Only a single textbox
    $(selector).bind('keydown',function(e)
		     {
			 if (e.keyCode == DOWN_KEY)
			 {
			     $('div#'+fillup+' ul li:nth-child('+ ++focused_at + ')').addClass('dropdown_selected_item').focus().siblings().removeClass('dropdown_selected_item');
			 }
			 else if (e.keyCode == UP_KEY)
			 {
			     $('div#'+fillup+' ul li:nth-child('+ --focused_at + ')').addClass('dropdown_selected_item').focus().siblings().removeClass('dropdown_selected_item');
			 }
			 else if (e.keyCode == TAB_KEY)
			 {
			     $('div#'+fillup+' ul li:nth-child('+focused_at+')').click();
			 }
			 else
			 {
			     host=details['host'];
			     db = details['db'];
			     table = details['table'];
			     keyfields = details['keyfields']; // The fields to search for
			     fields = details['fields']; // The fields to show
			     username = details['username'];
			     password = details['password'];
			     fillup = details['fillup'];
			     primarykey = details['primarykey'];
			     fillup_field = details['fillup_field'];
			     var onclick = details['onclick'];
			     
			     calling_field = $(this);
			     t = calling_field.offset().top;
			     l = calling_field.offset().left;
			     w = parseInt(calling_field.css('width'));

			     var key = calling_field.val();
			     if (key.length >= MIN_KEY_LENGTH && key.length<MAX_KEY_LENGTH)
			     {
				 $.post("https://phpmytable.000webhostapp.com/pmt/dropdown/load-items-from-regexp.php",
					{ host: host,
					  db: db,
					  table: table,
					  username: username,
					  password : password,
					  keyfields : keyfields,
					  fields : fields,
					  key: key,
					  primarykey: primarykey,
					  fillup_field:fillup_field,
					  onclick : onclick,
					  focused_at:focused_at
					}, function(data)
					{
					    
					    if (!data)
					    {
						$('div#'+fillup).hide();
						focused_at=0;
					    }
					    else
					    {
						$('div#'+fillup).
						    html(data).
						    css('top',t).
						    css('left', l + w+ 10).
						    slideDown();
                                            }
					});
			     }
			     else
			     {
				 $('div#'+fillup).hide();
				 focused_at=0;
			     }
			 }
		     });
    $('body').click(function ()
		    {
                	$('div#'+fillup).fadeOut();
                	focused_at=0;
		    });
}
