<html>

<head>
  <title>Citrus: Print</title>
  <style type="text/css" media="print,screen">
* {font-family:"helvetica","liberation sans", "arial", "sans-serif";}
body {margin-left:30px;margin-right:0.3in;}
h1 { font-size:larger;font-family:"liberation sans","helvetica","arial";border-bottom:1px solid #abc }
h2, h3 {margin:2px;font-family:"liberation sans","helvetica","arial";font-size: medium}
h3 {text-align:center}
table {width: 100%}
div.report {width:20cm;margins:1.5cm;border:1px solid #abc;padding:8px}
div.report_header {border:1px solid #abc;padding:5px;border-radius:5px}
div.reportedby {position:relative;left:500px;width:180px;text-align:left;top:-20px}
div.order {font-size:medium;font-weight:bold}
div.reportdate {margin-top:5px}
div.opinion {font-weight:bold;font-size:medium;margin-top:0.1in;margin-bottom:0.1in }
div, p, td {font-size:small}
div.second {margin-top:0.3in}
  </style>
  <style type="text/css" media="print">
    .dont_print {display: none}
  </style>
  <link rel="stylesheet" href="admin-letter-print.css"/>
  <script type="text/javascript" src="jquery.js"></script>
</head>

<body>

  <?php
  session_start();
  extract($_GET);
  extract($_SESSION);
  $host = "localhost";
  if ($_GET['table']) $table = $_GET['table']; else $table = $current_table;// If the table has been given in addressbar, take it
  $mysqli = new mysqli($host,$username, $password,"Citrus");
  $mysqli_lab = new mysqli($host,$username, $password,"Citrus");
  require_once('constants.php');
  $DATE_FORMAT = file_get_contents('DATE_FORMAT');

  function add_zero_before($number)
  {
      if (strlen($number) == 1)
	  return '0'.$number;
      else
	  return $number;
  }
  
  // Organs for the lab
  if ($table == 'Histopath') // Histo
  {
    $res=$mysqli_lab->query("SELECT * FROM Histopath_view WHERE HistopathID = '$pk'");
    echo $mysqli_lab->error;
    $row=$res->fetch_assoc();
    extract($row);
  ?>

      <div class="dont_print">
      <select name="page_choice" id="page_choice">
        <option value="2">Two reports per page</option>
        <option value="1">One report per page</option>
      </select>
      </div>
      
      <script type="text/javascript" src="lab-report-print.js"></script>
        
      <div class="report">
	<div class="report_header">
          <h1><?php echo $hospital ?></h1>
	  <h2>Department of Pathology</h2>
	</div>
	  <h3>Pathology Report</h3>
	    <span style="font-weight:bold"><?php echo $SampleID ?>-<?php echo $LabNo ?>-<?php echo(date_format(date_create($OrderDate),'Y'))?></span>
	    <table>
	      <tr>
		<td>Unit: <?php echo $Unit ?></td><td>Name: <?php echo $Relation ?> of <?php echo ($Pers_No_Prefix == 'OR')? '': $Pers_No_Prefix,$Pers_No_Num,$Pers_No_Suffix ?> <?php echo $Rank ?> <?php echo $PatientName ?></td>
		<td>Age: <?php echo ($Age ? $Age: ' ') ?> Sex: <?php echo $Sex?></td><td>Ward: <?php echo $WardName ?></td>
	      </tr>
	      <tr>
		<td>Organ: <?php echo $OrganName ?></td><td>Diagnosis : <?php echo $ClinicalDiag ?></td><td>Received on: <?php echo ($ReceivedDate!='0000-00-00 00:00:00') ? date(strtok($DATE_FORMAT,' '),strtotime($ReceivedDate)) : '' ?></td>
		  <td>Reported <?php echo date(strtok($DATE_FORMAT,' '),strtotime($ReportDate)) ?></td>
	      </tr>
	    </table>
	    <hr/>
	    <?php
	    if (!$Confirmed) echo "<p><center>PROVISIONAL REPORT</center></p>";
	    ?>
            <!--<?php /*
		if ($TestID == 1502) // IHC
		{
		$res_ihc = $mysqli_lab->query("SELECT Pathologists.Name AS ReporterName, Pathologists.Appointment
		FROM Histopath_view, Pathologists
		ON Histopath_view.ReportedBy = Pathologists.PathID
		AND Histopath_view.HistopathID= Results.OrderID AND Orders.TestID = '1502'");
		$row_ihc = $res_ihc->fetch_assoc();
		echo $mysqli->error;
		extract($row_ihc);
		?>
	    <div class="ihc"><strong>Immunohistochemistry report</strong> <?php echo nl2br($Microscopic) ?>
	    <br/>
	    <div class="opinion"><?php echo nl2br($Remarks) ?></div>
	    <br/>
	    <?php
	    }
	    else
	    {*/
	    ?>-->

	    <div class="macro"><p><strong>Gross</strong>: <?php echo nl2br($Macroscopic); ?></p></div>
	    <div class="micro"><p><?php echo ($Microscopic!=NULL) ? "<strong>Microscopic: </strong> ".nl2br(stripslashes($Microscopic)) : ""; ?></p></div>
	    <div class="opinion"><?php echo ($Microscopic!=NULL) ? "<strong>Opinion-</strong> ".(($OrganName == 'Other') ? '' : $OrganName.' - ').nl2br($Remarks) : "<strong>Microscopy and opinion: </strong>".nl2br($Remarks); ?></div>
	    <?php
	    $dt = new DateTime($ReportDate);
	    ?>
	    <div class="grossedby"><p>Grossed by <?php echo $GrosserName; ?></p></div>
	    <div class="reportdate"><?php echo $dt->format(strtok($DATE_FORMAT,' ')); ?></div>
	      <div class="reportedby"><p style="margin:0;padding:0"> 

	      <?php echo $ReporterName; ?> <br/> <?php echo $ReporterRank; ?><br/><?php echo $Appointment; ?></p></div>
	      <p style="text-align:center;margin:0;padding:0">-- END OF REPORT --</p>
	  </div>
	      
	<?php
	}
	?>
	<div class="dont_print">
      <select name="page_choice" id="page_choice">
        <option value="2">Two reports per page</option>
        <option value="1">One report per page</option>
      </select>
      </div>
	  <div class="edit_button dont_print">
		<a href="edit.php?pk=<?php echo $pk?>">Edit</a>
	  </div>
	  <?php
if ($table == 'Cytology') // Cytology
  {
    $res=$mysqli_lab->query("SELECT * FROM Cytology_view WHERE CytologyID = '$pk'");
    echo $mysqli_lab->error;
    $row=$res->fetch_assoc();
    extract($row);
  ?>

      
      
      <script type="text/javascript" src="lab-report-print.js"></script>
      <div class="report">
	<div class="report_header">
          <h1><?php echo $hospital ?></h1>
	  <h2>Department of Pathology</h2>
	</div>
	<h3><u>CYTOLOGY REPORT</u></h3>
        <div class="order">
	  <span style="font-weight:bold"><?php echo $SampleID ?>-<?php echo $LabNo ?>-<?php echo(date_format(date_create($OrderDate),'Y'))?></span></div>
	<table>
	  <tr>
	    <td>Name: <strong><?php echo $PatientName,' ',$Relation ?> of <?php echo ($Pers_No_Prefix) ? $Pers_No_Prefix : '', ($Pers_No_Num) ? $Pers_No_Num:'',($Pers_No_Suffix) ? $Pers_No_Suffix :'' ?> <?php echo $Rank ?> <?php echo $ServicePersName ?></strong></td>
	    <td>Age: <?php echo ($Age ? $Age: ' '), $Ageunit ?> Sex: <?php echo $Sex?></td><td>Ward: <?php echo $WardName ?></td>
	  </tr>
	  <tr>
	    <td>Organ: <?php echo $OrganName ?></td><td>Diagnosis : <?php echo $ClinicalDiag ?></td><td>Received on: <?php echo ($ReceivedDate!='0000-00-00 00:00:00') ? date(strtok($DATE_FORMAT,' '),strtotime($ReceivedDate)) : '' ?></td>
	    
	  </tr>
	</table>
	<hr/>
	<?php
	if (!$Confirmed) echo "<p><center>PROVISIONAL REPORT</center></p>";
	?>
	<div class="macro"><p><strong>Gross: </strong> <?php echo nl2br($Macroscopic); ?></p></div>
	<div class="micro"><p><?php echo ($Microscopic!=NULL) ? "<strong>Microscopic: </strong> ".nl2br($Microscopic) : ""; ?></p></div>
	<div class="opinion"><p><?php echo ($Microscopic!=NULL) ? "<strong>Opinion- </strong> ".$OrganName." : ".nl2br($Remarks) : "<strong>Microscopy and opinion: </strong>".nl2br($Remarks); ?></p></div>
	<?php
	$dt = new DateTime($ReportDate);
	?>
	<div class="reportdate"><?php echo $dt->format(strtok($DATE_FORMAT,' ')); ?></div>
	<div class="reportedby"><p> 
	  <?php echo $ReporterName; ?> <br/> <?php echo $ReporterRank; ?><br/><?php echo $Appointment; ?></p></div>
	  <p style="text-align:center">---END OF REPORT---</p>
      </div>
	
	<?php
	}    


if ($table == 'Hematology')
{
    $res=$mysqli_lab->query("SELECT * FROM `Hematology_view` WHERE `HematID` = '$pk'");
    if (!$res) echo $mysqli_lab->error;
    $row = $res->fetch_assoc();
    if (!$row) echo $mysqli_lab->error;
    extract ($row);

	echo '<div class="report">';
	$str = '<div class="report_header">';
    $str .= "<h1>".$hospital."</h1><h2>Department of Pathology</h2></div>";
    $str .= "<p/><h3><u>HEMATOLOGY RESULT</u></h3><p/><p/>";
    $str .= $HID." ".$Relation." of <strong>".$Pers_No_Prefix." ".$Pers_No_Num." ".$Pers_No_Suffix."  ".$Rank." ".$PatientName."</strong>";
    $str .= "<p>Ward : | <strong>".$WardName."</strong> | Age: ".(($Age) ? $Age : " ")." ".(($Age) ? $Ageunit : "")." Sex: ".$Sex."</p>";
	$str .= " <strong style='font-size:14pt'>".$SampleID."-".$LabNo."-".date_format(date_create($OrderDate),'Y')."</font></strong> Ordered on: ".date_format(date_create($OrderDate),$DATE_FORMAT)." Reported on: ".date_format(date_create($ReportDate),$DATE_FORMAT)."<br/>";
    $row_hemat = array_slice($row,$HEMAT_ROW_TEST_BEGINS,$HEMAT_ROW_TEST_ENDS);
	$str.='<table border="0">';
    foreach($row_hemat as $key=>$value)
	{
	    echo '<tr>';
	    if ($value != 0 && $value != '')
		{
		    if ($key != 'Remarks')
			{
			    $str.='<td>';
			    unset($Unit,$NormalLow,$NormalHigh);
			    $unit_res=$mysqli_lab->query("SELECT Unit, NormalLow, NormalHigh FROM Tests WHERE `Tests`.`Name`  = '$key'");
			    if (!$unit_res) $str .= $mysqli_lab->error;
			    $unit_row = $unit_res->fetch_assoc();
			    extract($unit_row);
			    $str .= "".$key." : </td><td><strong>".add_zero_before($value)."</strong> ".$Unit."</td><td>(".$NormalLow."-".$NormalHigh.")</td></tr>";
			}
		}
	}
	$str.='</table>';
    if ($Microscopic) $str .= "<p><u>Microscopy</u></p>".trim(nl2br($Microscopic));
    if ($Remarks) $str .="<p><u>Remarks</u>:</p>".trim($Remarks)."<br/>";
    
    $query="SELECT *, (SELECT Name FROM Ranks WHERE Ranks.RankID = Pathologists.RankID) AS Rank FROM Pathologists WHERE PathID='$ReportedBy'";
    $pathologist = $mysqli_lab->query($query);
    
    // Make an Indian format date of ReportDate
    $dt = new DateTime($ReportDate);
    if ($pathologist) $row=$pathologist->fetch_array(MYSQLI_ASSOC);
    $str .= "<p><br><br>\t\t\t\t\t\t\t(".$row['Name'].")<br/>\t\t\t\t\t\t\t".$row['Rank']."<br/>\t\t\t\t\t\t\t".$row['Appointment']."<br/>\t\t\t\t\t\t\t".$dt->format($DATE_FORMAT)."</p>";
	$str.="<center>---END OF REPORT---</center>";
    $str=wordwrap($str,120);
    echo $str."</pre></div>";
    // file_put_contents("hemat-result",$str);
    //shell_exec("cat hemat-result| pr -f -t| lpr -l");
}

elseif ($table == 'Biochemistry')
{
    $res=$mysqli_lab->query("SELECT *,YEAR(ReportDate) AS Year FROM `Biochemistry_view` WHERE `BiochemID` = '$pk'");
    if (!$res) echo $mysqli_lab->error;
    $row = $res->fetch_assoc();
    if (!$row) echo $mysqli_lab->error;
    extract ($row);
    echo '<style>body {margin:10px}</style><div style="width:23cm"><pre>';
    $str = "<strong>".$hospital." ".$address."</strong>\n";
    $str .= $HID." <strong>".$PatientName."</strong>";
    $str .= "\nWard : | ".$WardName." |";
    $str .= "\n--------------------";
    $str .= "\n\nBiochemistry result\n------------------\n";
    $str .= $SampleID."-".$BiochemID."-".$Year."\n\n";
    $row_biochem = array_slice($row,$BIOCHEM_ROW_TEST_BEGINS,$BIOCHEM_ROW_TEST_ENDS);
    foreach($row_biochem as $key=>$value)
	{
	    if ($value != 0 && $value != '')
		{
		    if ($key != 'Remarks')
			{
			    unset($Unit,$NormalLow,$NormalHigh);
			    $unit_res=$mysqli_lab->query("SELECT Unit, NormalLow, NormalHigh FROM Tests WHERE `Tests`.`Name`  = '$key'");
			    if (!$unit_res) $str .= $mysqli_lab->error;
			    $unit_row = $unit_res->fetch_assoc();
			    extract($unit_row);
			    $str .= "<strong>".$key."</strong> : ".$value." ".$Unit." ";
			}
		}
	}
    $query="SELECT Name, Appointment FROM Pathologists WHERE PathID='$ReportedBy'";
    $pathologist = $mysqli_lab->query($query);
    
    // Make an Indian format date of ReportDate
    $dt = new DateTime($ReportDate);
    if ($pathologist) $row=$pathologist->fetch_array(MYSQLI_ASSOC);
    $str .= "\n\n(".$row['Name'].")\n".$row['Appointment']."\n".$dt->format($DATE_FORMAT)."\n \n \n";
    $str=wordwrap($str,45);
    echo $str."</pre></div>";   
}


// Organs for Administration

elseif ($table == "Letters")
{
  ?>
  
  <script type="text/javascript" src="admin-letter-print.js"></script>
  <?php
  $mysqli_letters = new mysqli($host,$username,$password,$db);
  $res = $mysqli_letters->query("SELECT LetterID, Security, Contacts.Name AS SenderName, Contacts.Address AS SenderAddress, Date, Branches.Name as BranchName, Salutation, Subject, Content, Ranks.Name AS Rank, Officers.Name AS OfficerName,
			Officers.Appt, Attachments
			FROM Letters, Officers, Contacts, Ranks, Branches
			WHERE Letters.SenderID = Contacts.ContactID
			AND Letters.OfficerID = Officers.OfficerID
			AND Officers.RankID = Ranks.RankID
			AND Branches.BranchID = Letters.BranchID
			AND Letters.LetterID =  '$pk' LIMIT 0,1");
  echo $mysqli_letters->error;
  $row =$res->fetch_assoc();
  extract($row);
  $formatted_date = date_format(new DateTime($Date), strtok($DATE_FORMAT," "));
  $year = date_format(new DateTime($Date),"Y");
  ?>
  <table id="letter_print" border="1">
    <thead>
      <tr>
	<th colspan="2"><?php echo $Security?></th>
      </tr>
    </thead>
    <tbody>
      <tr>
	<td colspan="2" id="letter_print_sender">
	  <div id="letter_print_sender_name"><?php echo $SenderName?></div>
	  <div id="letter_print_sender_address"><?php echo $SenderAddress?></div>
	</td>
      </tr>
      <tr>
	<td id="letter_print_date"><?php echo $formatted_date?></td>
        <td id="letter_print_fileref"><?php echo $LetterID?>/<?php echo$BranchName?>/<?php echo$year?></td>
      </tr>
      <tr colspan="2">
	<td id="letter_print_primary_recipients">
	  <?php
	  $primary_recipient_ref=$mysqli_letters->query("SELECT Contacts.Name, Contacts.Address
					FROM Recipients, Contacts
					WHERE Recipients.Type = 'primary'
					AND Contacts.ContactID = Recipients.ContactID
					AND Recipients.LetterID = '$pk'");
	  while ($primary_recipient_row = $primary_recipient_ref->fetch_assoc())
	  {
	    extract($primary_recipient_row);
	  ?>
	    <div class="letter_print_primary_recipient"><?php echo $Name ?><br/><?php echo $Address ?></div>
	  <?php
	  }
	  ?>
	</td>
      </tr>
      <tr colspan="2">
	<td id="letter_print_subject"><?php echo $Subject?></td>
      </tr>
      <tr colspan="2">
	<td id="letter_print_salutation"><?php echo $Salutation?>
	</td>
      </tr>
      <tr colspan="2">
	<td id="letter_print_content"><?php echo nl2br(str_replace(' ', '&nbsp;', $Content))?></div>
	</td>
      </tr>
      <tr colspan="2">
	<td id="letter_print_subscription">
	  <div id="letter_print_officer_name"><?php echo $OfficerName?></div>
	  <div id="letter_print_rank"><?php echo $Rank?></div>
	  <div id="letter_print_appt"><?php echo $Appt?></div>
	</td>
      </tr>
      <tr colspan="2">
	<td id="letter_print_attachments">
	  Encl -<p><?php echo $Attachments?></p>
	</td>
      </tr>
      <tr colpan="2">
	<td id="letter_print_copy_recipients">Copy to -
	  <?php
	  $copy_recipient_ref=$mysqli_letters->query("SELECT Contacts.Name, Contacts.Address
					FROM Recipients, Contacts
					WHERE Recipients.Type = 'copy'
					AND Contacts.ContactID = Recipients.ContactID
					AND Recipients.LetterID = '$pk'");
	  while ($copy_recipient_row = $copy_recipient_ref->fetch_assoc())
	  {
	    extract($copy_recipient_row);
	  ?>
	    <div class="letter_print_copy_recipient"><?php echo $Name ?><br/><?php echo $Address ?></div>
	  <?php
	  }
	  ?>
	</td>
      </tr>
      <tr colspan="2">
	<td id="letter_print_info_recipients">
	  <?php
	  $info_recipient_ref=$mysqli_letters->query("SELECT Contacts.Name, Contacts.Address
					FROM Recipients, Contacts
					WHERE Recipients.Type = 'info'
					AND Contacts.ContactID = Recipients.ContactID
					AND Recipients.LetterID = '$pk'");
	  while ($info_recipient_row = $info_recipient_ref->fetch_assoc())
	  {
	    extract($info_recipient_row);
	  ?>
	    <div class="letter_print_info_recipient"><?php echo $Name ?><br/><?php echo $Address ?> - for info pl</div>
	  <?php
	  }
	  ?>
	</td>
      </tr>
    </tbody>
    <tfoot>
      <tr colspan="2">
	<td id="footer"><?php echo $Security ?></td>
      </tr>
    </tfoot>
  </table>
<?php
}
?>
</body></html>
