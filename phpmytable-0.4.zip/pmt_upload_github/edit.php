<?php
session_start();
?>

<html>
  <head>
    <title>Edit</title>
  </head>

<body>
<div class="notice"></div>

<?php
require_once('constants.php');
extract($_SESSION);
require_once('template.php');
extract($opts);
extract($_GET);
if (isset($_GET['table'])) $table=$_GET['table']; else $table=$current_table;
$primary_key = $current_primary_key;
$mysqli = new mysqli($host,$username,$password,$db);
$sql = "SELECT * FROM `$table` WHERE `$primary_key` = '$pk'";
$res=$mysqli->query($sql);
echo $mysqli->error;
$row=$res->fetch_row();
$fields=$res->fetch_fields();
?>

<div class="edit">
<div class="close_button"><a href="javascript:window.close();"><img src="images/close.png" alt="Close" title="Close"></a></div>
<div id="current_table"><?php echo $current_table ?></div>

<?php
echo '<form name="edit_record_form" id="edit_record_form" method="POST" action="update.php">';
$i = 0;
echo '<input type="hidden" name="current_table" value="',$current_table,'"/>';
echo '<input type="hidden" name="current_primary_key" value="',$current_primary_key,'"/>';
for ($i = 0; $i < count($fields); $i++)
    {
	echo '<div class="field ', $fields[$i]->name, '">';
	echo '<div class="edit_label"><label class="',$fields[$i]->name,' ';
	if ($primary_key==$fields[$i]->name) echo " primary_key ";
	echo '">',$fields[$i]->name,'</label></div>';

	echo '<div class="edit_value">';
	if ($fields[$i]->type == $TEXT_FIELD_TYPE) // Text field
	    echo '<textarea rows="5" cols="10"';
	elseif ($opts['refs'][$fields[$i]->name]) // This field is a reference
	    echo '<select ';
	else
	    echo '<input type="text" value="',
		$row[$i],
		'" ';
	echo 'title="',
	    $fields[$i]->name,
	    '" name="',
	    $fields[$i]->name,
	    '" id="',
	    $fields[$i]->name,
	    '" class="',
	    $fields[$i]->name;
	 if ($fields[$i]->type == $DATETIME_FIELD_TYPE || $fields[$i]->type == $TIMESTAMP_FIELD_TYPE)
	    echo ' date_field ';
	echo '">';

	if ($fields[$i]->type == $TEXT_FIELD_TYPE)
	    echo $row[$i],'</textarea></div>';
	elseif ($opts['refs'][$fields[$i]->name])
	    {
		$ref = $opts['refs'][$fields[$i]->name];
		if ($ref['foreign_key'])
		    {
			$ref_sql = "SELECT ". $ref['foreign_key'] . ", " . $ref['display_field'] . " FROM " . $ref['table'];
			$ref_results=$mysqli->query($ref_sql);
			echo '<option value=""></option>';
			while($ref_row=$ref_results->fetch_assoc())
			    {
				if ($row[$i] == $ref_row[$ref['foreign_key']])
				    echo '<option selected value="',$ref_row[$ref['foreign_key']],'">',$ref_row[$ref['display_field']],'</option>';
				else
				    echo '<option value="',$ref_row[$ref['foreign_key']],'">',$ref_row[$ref['display_field']],'</option>';
			    }
		    }
		else
		    {
			foreach ($ref as $val)
			    {
				echo '<option value="',$val,'">',$val,'</option>';
			    }
		    }
		echo '</select></div>';
	    }
	else
	    echo '</input></div>';
	echo '</div>';
    }
    
  echo '<div id="multiple_entry_buttons">';
  foreach($opts['multiple_refs'] as $ref)
  {
  echo<<<END
  <a class="fancy_button" href="javascript:void(0)"
	  onclick="open_multiple_entry_table('{$ref['table']}','{$ref['foreign_key']}',
		   '{$ref['primary_key']}')">
    Add from {$ref['table']}</a>
END;
  }
  echo '</div>';
  echo '<input type="image" src="images/yes.png" alt="Update" id="Update"></input></form>';
  ?>
</div></body></html>
