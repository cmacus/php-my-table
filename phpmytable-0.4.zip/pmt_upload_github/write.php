<?php
session_start();
extract($_SESSION);
extract($opts);
$table=$_GET['current_table'];
$mysqli = new mysqli($host,$username,$password,$db);
$sql = "INSERT INTO `$table` SET ";
foreach($_GET as $key => $value)
{
    if ($key != 'current_table')
    {
	if ($value)
	{
	    $value = $mysqli->real_escape_string(addSlashes($value));
	    $sql .= "`$key`='$value',";
	}
    }
}
$sql=substr($sql,0,-1);
$res=$mysqli->query($sql);
$row_id=$mysqli->insert_id;
echo<<<END
{
    "row_id" : "{$row_id}",
    "result" : "
END;
echo ($res) ? "Result updated" : $sql.'<br/>'.$mysqli->error;
echo '" }';

?>
