<?php
require_once('create-select-box-from-db.php'); // Creates a select box from a database, table and given field
require_once('constants.php');
ini_set('display_errors','Off');

?>

<!-- Optional, not yet implemented -->
<link rel="stylesheet" type="text/css" href="mobile.css" media="only screen and (max-width: 480px)" />

<!-- Stylesheet for the phpMyTable project -->
<link rel="stylesheet" type="text/css" href="styles/phpMyTable.css" media="screen and (min-width: 481px)" />

<!-- The dropdown project stylesheet -->
<link rel="stylesheet" href="dropdown/dropdown.css"/>

<!-- Jquery -->
<script type="text/javascript" src="scripts/jquery.js"></script>

<!-- Script for phpMyTable project -->
<script src="scripts/phpMyTable.js"></script>

<!-- Script for the dropdown project-->
<script type="text/javascript" src="dropdown/dropdown.js"></script>

<!-- JSCalendar -->
<style type="text/css">@import url(jscalendar/calendar-mac.css);</style>
<script type="text/javascript" src="jscalendar/calendar.js"></script>
<script type="text/javascript" src="jscalendar/lang/calendar-en.js"></script>
<script type="text/javascript" src="jscalendar/calendar-setup.js"></script>

<div class="notice dont_print"></div>

<!-- Dropdown div -->
<div id="fillup" class="dont_print"></div>
