<?php
session_start();
extract($_SESSION);
extract($_GET);
extract($opts);
global $mysqli,$TEXT_FIELD_TYPE, $TIMESTAMP_FIELD_TYPE, $DATETIME_FIELD_TYPE,$DATE_FORMAT;
$DATE_FORMAT = file_get_contents('DATE_FORMAT');
echo $host, $username, $password, $db;
$mysqli = new mysqli($host,$username,$password,$db);
$res = $mysqli->query("SELECT * FROM `$table` WHERE `$primary_key` = '$pk'");
if (!$res) die($mysqli->error);
$fields=$res->fetch_fields();

$i=0;
$row = $res->fetch_assoc();

foreach ($row as $key=>$value)
{
    if (array_key_exists($key,$opts['refs']))
    {
	if (array_key_exists('table',$opts['refs'][$key]))
	{
	    $str = "SELECT `{$opts['refs'][$key]['display_field']}`
		    FROM `{$opts['refs'][$key]['table']}`
		    WHERE `{$opts['refs'][$key]['table']}`.`{$opts['refs'][$key]['foreign_key']}` = '$value'";
		    $res_ref = $mysqli->query($str);
		    $res_ref_row = $res_ref->fetch_row();
	    echo '<div class="show_label">',$key,'</div><div class="show_value">', $value, " : ", $res_ref_row[0], '</div>';
	}
	else
	    echo '<div class="show_label">',$key,'</div><div class="show_value">', $value,'</div>';
    }
    elseif (array_key_exists('ref_display_fields',$opts))
	{
			if 	(array_key_exists($key,$opts['ref_display_fields']))
			{
					extract($opts['ref_display_fields'][$key]);
					$mysqli_ref_display = new mysqli($host,$username,$password,$original_db);
					$sql = "SELECT `$ref_table`.`$ref_display_field`
							      FROM $ref_table, $original_table
							      WHERE `$original_table`.`$original_field` = `$ref_table`.`$ref_field`
							      AND `$original_table`.`{$key}` = '$value'";
					
					$res = $mysqli_ref_display->query($sql);
					$row = $res->fetch_row();
					echo '<div class="show_label">',$key,'</div><div class="show_value">', $value,'
					: <span class="ref_display">',nl2br($row[0]),'</div>';
	
			}
	}
    else
    {
	echo '<div class="show_label">',$key,'</div><div class="show_value">';
	if ($fields[$i]->type == $DATETIME_FIELD_TYPE || $fields[$i]->type == $TIMESTAMP_FIELD_TYPE)
	{
	    $dt=new DateTime($row[$i]);
	    echo $dt->format($DATE_FORMAT);
	}
	else
	echo $value, '</div>';
    }
    $i++;
}

?>
