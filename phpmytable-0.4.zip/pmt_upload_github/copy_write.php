<?php
session_start();
extract($_SESSION);
extract($opts);
extract($_POST);
$mysqli = new mysqli($host,$username,$password,$db);
$sql = "INSERT INTO `$table` VALUES(";
foreach($_POST as $key => $value)
{
	if ($key == $primary_key)
	{
		$sql .= "'',";
	}
	else
	{
		$sql .= "'$value',";
	}
}
$sql = substr($sql,0,-1);
$sql .= ")";
$res=$mysqli->query($sql);
echo ($res) ? "Result updated" : $sql.": ".$mysqli->error;
?>
