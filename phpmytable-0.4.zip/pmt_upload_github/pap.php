<html>

  <head>
    <style>
    * {font-family:"liberation sans";}
    table {border:1px solid #abc;width:50%;margin:auto}
    td,th {border:1px solid #abc}
    body {margin:10px}
    </style>
  </head>
  
  <body>
    <h1>Pap smears: Dimapur, Dinjan</h1>
    <hr/>
    <h2>Objectives</h2>
    <ol>
      <li>To categorise Pap smear results in a multihospital study of North east India</li>
    </ol>
    <h2>Materials and methods</h2>
    <h3>Study population</h3>
    <p>Women of 20-70 years, who have undergone Pap smear for screening purposes</p>
    <h3>Sample size</h3>
    <?php
    error_reporting('E_STRICT');
    ini_set( "display_errors", 1 ); // For development only
    $mysqli=new mysqli("localhost","root","Andalusia","Pap_study");
    $res = $mysqli->query("SELECT COUNT(*) FROM List");
    $row = $res->fetch_row();
    $total = $row[0];
    echo '<p>',$total,'</p>';
    ?>
    <h3>Exclusion criteria</h3>
    <p>Symptomatic patients</p>
    <h3>Study period</h3>
    <p>Sep 2015 - Jun 2016</p>
    <h2>Results</h2>
    <h3>Age distribution</h3>
    <?php
    $res = $mysqli->query("SELECT t.AgeRange, COUNT(*) AS `Num` FROM
(SELECT CASE
WHEN Age BETWEEN 16 and 20 THEN '16-20'
WHEN Age BETWEEN 21 and 25 THEN '21-25'
WHEN Age BETWEEN 26 and 30 THEN '26-30'
WHEN Age BETWEEN 31 and 35 THEN '31-35'
WHEN Age BETWEEN 36 and 40 THEN '36-40'
WHEN Age BETWEEN 41 and 45 THEN '40-45'
WHEN Age BETWEEN 46 and 50 THEN '46-50'
WHEN Age BETWEEN 51 AND 55 THEN '51-55'
WHEN Age BETWEEN 56 AND 60 THEN '56-60'
WHEN Age BETWEEN 61 AND 65 THEN '61-65'
WHEN Age BETWEEN 66 AND 70 THEN '66-70'
WHEN Age BETWEEN 71 AND 75 THEN '71-75'
WHEN Age BETWEEN 76 AND 80 THEN '76-80'WHEN Age BETWEEN 76 AND 80 THEN '76-80' WHEN Age BETWEEN 76 AND 80 THEN '76-80'
END AS AgeRange FROM List) t GROUP BY AgeRange");
    echo '<table>';
    while ($row = $res->fetch_row())
	{
	    echo '<tr>';
	    echo '<td>',$row[0],'</td><td>',$row[1],'</td><td>',round($row[1]*100/$total,2),'%</td>';
	    echo '</tr>';
	}
    echo '<tr><td>Total<td>',$total,'</td>';
    echo '</table>';
    
    echo '<h3>Length of stay with husband in last 5 years</h3>
<img src="length_of_stay_histogram.png"/>';
    echo '<h3>Nature of lesions</h3>';
    $res = $mysqli->query("SELECT Nature, COUNT(*) FROM List GROUP BY Nature");
    echo '<table>';
    while ($row = $res->fetch_row())
	{
	    echo '<tr>';
	    echo '<td>',$row[0],'</td><td>',$row[1],'</td><td>',round($row[1]*100/$total,2),'%</td>';
	    echo '</tr>';
	}
    echo '<tr><td>Total<td>',$total,'</td>';
    echo '</table>';
    
    echo '<h3>Religion</h3>';
    $res = $mysqli->query("SELECT Religion, COUNT(*) FROM List GROUP BY Religion");
    echo '<table>';
    while ($row = $res->fetch_row())
	{
	    echo '<tr>';
	    echo '<td>',$row[0],'</td><td>',$row[1],'</td><td>',round($row[1]*100/$total,2),'%</td>';
	    echo '</tr>';
	}
    echo '<tr><td>Total<td>',$total,'</td>';
    echo '</table>';

    echo '<h3>Categories</h3>';
    $res = $mysqli->query("SELECT Cat, COUNT(*) FROM List GROUP BY Cat");
    echo '<table>';
    while ($row = $res->fetch_row())
	{
	    echo '<tr>';
	    echo '<td>',$row[0],'</td><td>',$row[1],'</td><td>',round($row[1]*100/$total,2),'%</td>';
	    echo '</tr>';
	}
    echo '<tr><td>Total<td>',$total,'</td>';
    echo '</table>';

    echo '<h3>Age and nature of lesion</h3>';
    $arr = array();
    $low = 16;
    $high = 85;
    $step = 4;
    $res = $mysqli->query("SELECT * FROM List");
    while ($row = $res->fetch_assoc())
    {
	$range_low = $low;
	$range_high = $range_low + $step;
	
	extract($row);
	while ($range_high <= $high)
	{
	    if ($Age >= $range_low && $Age <= $range_high)
	    {
		$arr[$range_low.'-'.$range_high][$Nature]++;
		$arr[$range_low.'-'.$range_high]['total']++;
	    }
	    $range_low += $step + 1;
	    $range_high += $step + 1;
	}
	
    }
    ksort($arr);
    echo '<table><tr><th>Age range</th><th>Nature</th><th>Num</th><th>%</th></tr>';
    foreach ($arr as $k=>$v)
    {
	$num_rows = count($v)-1;
	echo '<tr><td rowspan="',$num_rows,'">',$k,'</td>';
	foreach ($v as $k2=>$v2)
	{
	    if ($k2 != 'total')
		echo '<td>',$k2,'</td><td>',$v2,'</td><td>',round($v2*100/$arr[$k]['total'],2),'</td></tr>';
	}
    }
    echo '</table>';
    echo '<h3>Age and category of lesion</h3>';
    $arr = array();
    $low = 16;
    $high = 85;
    $step = 4;
    $res = $mysqli->query("SELECT * FROM List");
    while ($row = $res->fetch_assoc())
    {
	$range_low = $low;
	$range_high = $range_low + $step;
	
	extract($row);
	while ($range_high <= $high)
	{
	    if ($Age >= $range_low && $Age <= $range_high)
	    {
		$arr[$range_low.'-'.$range_high][$Cat]++;
		$arr[$range_low.'-'.$range_high]['total']++;
	    }
	    $range_low += $step + 1;
	    $range_high += $step + 1;
	}
	
    }
    ksort($arr);
    echo '<table><tr><th>Age range</th><th>Nature</th><th>Num</th><th>%</th></tr>';
    foreach ($arr as $k=>$v)
    {
	$num_rows = count($v)-1;
	echo '<tr><td rowspan="',$num_rows,'">',$k,'</td>';
	foreach ($v as $k2=>$v2)
	{
	    if ($k2 != 'total')
		echo '<td>',$k2,'</td><td>',$v2,'</td><td>',round($v2*100/$arr[$k]['total'],2),'</td></tr>';
	}
    }
    echo '</table>';
    ?>
