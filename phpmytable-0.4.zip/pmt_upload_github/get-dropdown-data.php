<?php
session_start();
extract($_SESSION);
extract($_GET);
$mysqli = new mysqli($host,$username,$password,$db);
$sql="SELECT $fillup_field FROM $table WHERE $keyfield = $key LIMIT 0,1";
$res=$mysqli->query($sql);
if (!$res) die($mysqli->error);
$row = $res->fetch_row();
echo $row[0];
?>