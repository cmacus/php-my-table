var PRESENT_CENTURY = 2000;
UP_KEY=38;
DOWN_KEY=40;
ENTER_KEY=13;
TAB_KEY=9;
ESCAPE_KEY=27;

error_count=0;

selected_records = [];

function flash_notice(data)
{
	$('div.notice').hide('fast').slideDown('fast').html(data);
}

function open_multiple_entry_table(table,foreign_key,primary_key)
{
    window.open(table.toLowerCase()+'.php?new=1&'+ foreign_key + '='+ $('label#row_id').html());
}

function capitalize(text)
{
    return(text.toUpperCase());
}
function convert_text_to_date(str, output_separator) // Make a date like 01 Sep 15 or 1/9/15 to 2015-09-01
{
    if (str.match('/')) {
	separator = '/';
    }
    else
	separator = ' ';
    var parts = str.split(separator);
    var months = ['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];
    for (i=0;i<12;i++)
    {
	if (isNaN(parts[1]))
	    {
		if (months[i].toUpperCase() == parts[1].toUpperCase())
		{
		    selected_month = i+1;
		}
	    }
	else
	{
	   selected_month = parts[1];
	}
    }
    if (selected_month < 10)
	selected_month = '0' + selected_month;
    selected_year = (parts[2].length < 3) ? parseInt(parts[2]) + PRESENT_CENTURY : parts[2];
    selected_date =  (parts[0].length < 2) ? '0' + parts[0]: parts[0];
    if (selected_date > 31 || selected_month > 12)
	return null;
    else
	return(selected_year+output_separator+selected_month+output_separator+selected_date);
}

$(function()
  {
	$('.action_buttons').hide();
	current_table = $('div#current_table').html(); // Set current table
	current_primary_key = $('div#page_details span#primary_key').html();
    $('#sql').hide().fadeOut('fast').fadeIn('fast')

    $('table#results input, table#results textarea,table#results a, table#results button').focus(function()
	{
			   $(this).parents('td').addClass('active');
			   $(this).parents('tr').addClass('active');
		       }
		       );
      $('table#results input, table#results textarea,table#results a').blur(function()
		      {
			  $(this).parents('td').removeClass('active');
			  $(this).parents('tr').removeClass('active');
		      }
		      );
      if ($('table#results tr.result')) $('tr#new_result').hide();
      // bind change event to select box (page number)
      $('div.paginate').clone().insertAfter('#results');
      $('select.page_numbers').change(function() 
			      {
				  var pagenum = $(this).val();
				  if (pagenum) // require a URL
				      { 
					  window.location.href = window.location.pathname + "?page_number=" + pagenum; // redirect
				      }
				});

      $('div.record_form').hide().fadeOut('fast').fadeIn('fast')
      
      // Search form submit on change of dropdown
      $('select.search').change(function()
							{
							    $('form.search_form').submit();
							});
      // Search form submit on clicking search image
      $('#search_button').click(function(event)
			       {
				    event.preventDefault();
				   $('form.search_form').submit();
			       });

      $('div.show').hide();
      $('.show_button').click(function()
		       {
			   parent_row = $(this).parents('tr');
			   t = parent_row.offset().top;
			   primary_key = $(this).parents('tr').attr('id');
			   $.get("show.php", {pk : primary_key}, function(data)
				 {
				     $('.show .content').html(data);
				     $('.show').fadeOut('fast').fadeIn('fast')
				 });
		       });
      $('div.show .close_button').click(function()
			      {
				  $('.show').hide();
			      });
      $('.delete_button').click(function()
				{
				    calling_row = $(this).parents('tr');
				    primary_key = $(this).parents('tr').attr('id');
				    if (confirm("Really delete record " + primary_key + " ?"))
					{
					    $.get("delete.php", {pk : primary_key}, function(data)
						  {
						    flash_notice( (data=='0') ? 'Record ' + primary_key + ' deleted' : data);
						    if (data == '0')
							$(calling_row).remove();
						  });
					}
				});
	$('.copy_button').click(function()
				{
				    primary_key = $(this).parents('tr').attr('id');
				    window.open("copy.php?pk="+primary_key);
				});
	$('.copy #copy_record_form').submit(function(event)
				   {
				       event.preventDefault();
				       $.post("copy_write.php",$(this).serialize(),function(data)
					     {
						 window.opener.location.reload();
						 flash_notice(data);
					     });
				   });

      $('.update_form').submit(function(event)
				   {
				    
				       event.preventDefault();
				       $.post("update.php?current_table="+current_table,$(this).serialize(),function(data)
					     {
						 //window.location.reload();
						 flash_notice(data);
					     });
				   });
      $('table#results .field').blur(function()
					    {	
						$.post("update.php?current_table="+current_table,$(this).parents('td').siblings('form.update_form').serialize(),function(data)
						{
						    
						 //window.location.reload();
						    if (data)
						    {
							flash_notice(data);
						    }
						});
					    });
      $('.new_button').click(function()
			     {
				 $('div.new').fadeIn('fast');
				 $('form#new_record_form input:first').focus();
				 
			     });
      
      $('.edit_button').click(function()
			      {
				  primary_key = $(this).parents('tr').attr('id');
				  window.open("edit.php?pk="+primary_key+"&current_table="+current_table+"&current_primary_key="+current_primary_key);
				  $('#edit_record_form input:first').focus();
			      });
     $('.edit #edit_record_form').submit(function(event)
				   {
				       event.preventDefault();
				       $.post("update.php?current_table="+current_table,$(this).serialize(),function(data)
					     {
						 window.opener.location.reload();
						 flash_notice(data);
					     });
				   });


      $('#new_record_form').submit(function(event)
				   {
				       event.preventDefault();
				       $.getJSON("write.php",$(this).serialize(),function(data)
					     {
						 flash_notice(data.result);
						 $('label#row_id').html('<a href="print.php?table=' + current_table +'&pk=' + data.row_id +'">' + data.row_id + 	'</a>').show();
					     });
				       $('#new_record_form input:first').focus();
				   })
      $('.print_button').click(function()
			       {
				   primary_key = $(this).parents('tr').attr('id');
				   window.open("print.php?pk=" + primary_key + "&table="+ current_table);
				   });
      // The print function can be delegated to private Javascript, as each template is different

      $('#results tr').hover(function(event)
			     {
				 $(this).children('td').children('.action_buttons').show();
				 $(this).addClass('active');
			     },
			     function()
			     {
				 $(this).children('td').children('.action_buttons').hide();
				 $(this).removeClass('active');
			     });


      $('div.new input,div.edit input,div.copy input, div.new select,div.edit select,div.copy select, div.new textarea,div.edit textarea,div.copy textarea').focus(function()
					      {
						  $('div.new input,div.edit input,div.copy input, div.new select,div.edit select,div.copy select, div.new textarea,div.edit textarea,div.copy textarea').removeClass('active');
						  $(this).addClass('active');
						  $('span.suggestion').remove();
						  $('<span class="suggestion"/>').insertAfter(this).html($(this).attr('suggestion'));
					      });
      $('div.new input,div.edit input, div.new select,div.edit select, div.new textarea,div.edit textarea').blur(function()
					      {
						  $(this).removeClass('active');
						  });
      $('input.selected').click(function()
				    {
					primary_key = $(this).parents('tr').attr('id');
				
					if ($(this).attr('checked')=='true') 
					    {
						deselect_this_record(primary_key);
						
					    }
					else
					    {
						select_this_record(primary_key);
						
					    }
				    });
      function select_this_record(primary_key)
      {	
		selected_records.push(primary_key);
      }
      
      function deselect_this_record(primary_key)
      {
		selected_records.pop(primary_key);
      }
	  
      $('input#select_all').click(function()
				  {

				      if ($(this).attr('checked')==true) // To be selected
					  {
					      $('table#results tr').each(function()
									 {
									     select_this_record($(this).attr('id'));
									 });
					      $('input.selected').attr('checked',true);
					  }
				      else
					  {
					      $('table#results tr').each(function()
									 {
									     deselect_this_record($(this).attr('id'));
									 });
					      
					      $('input.selected').attr('checked',false);
					  }
				  });
        
	
	// Global update form
	$('#global_update_form_submit').click(function()
					      {
							$('form#global_update_form').submit();
					      });
	
	// New record form
	$('img#Add').click(function()
					      {
						$('form#new_record_form').submit();
					      });
	
      // Add a calendar to date-time fields
      date_field_count=0;
      $('input.date_field').each(function()
				 {
				     date_field_count++;		
				     new_button = ' <button class="trigger_calendar" id="date_button_' + date_field_count +'">...</button>';
				     $(this).after(new_button);
				     
				     // $(this).attr('id','date_field_'+ date_field_count + "_" + row_id);
				     if ($(this).attr('class','search'))
				     {
					 Calendar.setup (
					     {
						 inputField : $(this).attr('id'),
						 ifFormat: "%Y-%m-%d",
						 button: $(this).next('button.trigger_calendar').attr('id'),
						 showsTime: true,
						 weekNumbers: false
					     }); 
				     }
				     else
				     {
					 Calendar.setup (
				             {
						 inputField : $(this).attr('id'),
						 ifFormat: "%Y-%m-%d %H:%M:%S",
						 button: $(this).next('button.trigger_calendar').attr('id'),
						 showsTime: true,
						 weekNumbers: false
					     });
				     }
				     $(this).blur(function()
						  {
							$(this).val(convert_text_to_date($(this).val(),'-'));
						  });
				 });
      $('div.notice img#close_notice').click(function()
					     {
						 $('div.notice').hide();
					     })


      // Auto fill 'OrderDate' fields
      var today = new Date();
      var dd = today.getDate();
      var mm = today.getMonth()+1; //January is 0!
      var yyyy = today.getFullYear();
      
      if(dd<10) {
	  dd='0'+dd
      } 
      
      if(mm<10) {
	  mm='0'+mm
      } 
      
      today = yyyy+'-'+mm+'-'+dd;
      $('input#OrderDate').val(today);
      
      // Click fields
      $('input.click_field').dblclick(function()
				      {
					    window.open($(this).attr('click_table_page') + '?search=1&' + $(this).attr('click_primary_key') + '=' + $(this).val());
				      });
      // Escape key functions
      $('div.new').keydown(function(e)
			{
			    if (e.keyCode == ESCAPE_KEY)
			    {
				$('div.new').hide();
			    }
			});
      
      $('div.edit, div.copy').keydown(function(e)
			{
			    if (e.keyCode == ESCAPE_KEY)
			    {
				$(this).hide();
				window.close();
			    }
			});
	  
	  
	  // Input validations - email, capital, required, numeric, character with length, password with required characters
	  
		$('input.numeric, textarea.numeric').blur(function()
							  {
								if (isNaN($(this).val()))
								{
									$('span.validation_warning_numeric').html('').remove();
									$(this).after(' <span class="validation_warning_numeric">Please enter numbers only</span>');
                                    $(this).focus();
                                }
								else
									$('span.validation_warning_numeric').html('').remove();
							  }
							  );
		$('input.required, select.required, textarea.required').blur(function()
		{
			if ($(this).val()=='')
            {
									$('span.validation_warning_required').html('').remove();
									$(this).after(' <span class="validation_warning_required">This is a required field</span>');
                                    $(this).focus();
			}
			else
				$('span.validation_warning_required').html('').remove();
		});
		
		$('input.character, textarea.character').blur(function()
													  {
														if (!isNaN($(this).val()))
															{
																$('span.validation_warning_character').html('').remove();
																$(this).after(' <span class="validation_warning_character">No numbers, only characters</span>');
																$(this).focus();			
															}
														else
																$('span.validation_warning_character').html('').remove();																														
													  })
		$('input.capital, textarea.capital').blur(function()
                                     {
                                      $(this).val(capitalize($(this).val()));
                                     });
		
		
      //Navigation within results table
      $('table#results input.field').keydown(function(e)
					     {
						 fieldName = $(this).attr('name');
						 if (e.keyCode == DOWN_KEY)
						     $(this).parents('tr').next().find('input.field[name='+fieldName+']').focus();
						 else if (e.keyCode == UP_KEY)
						     $(this).parents('tr').prev().find('input.field[name='+fieldName + ']').focus();
					     });
 });
