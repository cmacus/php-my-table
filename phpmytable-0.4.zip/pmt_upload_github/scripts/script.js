$(function()
  {
      $('.action_button').hide();
      $('.notice').hide();
      $('#sql').hide().fadeIn('fast');

      $('table#results input, table#results textarea,table#results a, table#results button').focus(function()
		       {
			   $(this).parents('td').addClass('active');
			   $(this).parents('tr').addClass('active');
		       }
		       );
      $('table#results input, table#results textarea,table#results a').blur(function()
		      {
			  $(this).parents('td').removeClass('active');
			  $(this).parents('tr').removeClass('active');
		      }
		      );
      if ($('table#results tr.result')) $('tr#new_result').hide();
      // bind change event to select box (page number)
      $('div.paginate').clone().insertAfter('#results');
      $('select.page_numbers').change(function() 
			      {
				  var pagenum = $(this).val();
				  if (pagenum) // require a URL
				      { 
					  window.location.href = window.location.pathname + "?page_number=" + pagenum; // redirect
				      }
			      });

      $('div.record_form').hide().fadeIn('fast');
      
      // Search form submit on change of dropdown
      $('select.search').change(function()
							{
							    $('form.search_form').submit();
							});

      $('div.show').hide();
      $('.show_button').click(function()
		       {
			   parent_row = $(this).parents('tr');
			   t = parent_row.offset().top;
			   primary_key = $(this).parents('tr').attr('id');
			   $.get("show.php", {pk : primary_key}, function(data)
				 {
				     $('.show .content').html(data);
				     $('.show').offset({top:t}).fadeIn('fast');
				 });
		       });
      $('.show .close').click(function()
			      {
				  $('.show').hide();
			      });
      $('.delete_button').click(function()
				{
				    primary_key = $(this).parents('tr').attr('id');
				    if (confirm("Really?"))
					{
					    $.get("delete.php", {pk : primary_key}, function(data)
						  {
						      $('div.notice').html(data).hide().fadeIn('fast');
						      window.location.reload();
						  });
					}
				});
	$('.copy_button').click(function()
				{
				    primary_key = $(this).parents('tr').attr('id');
				    window.open("copy.php?pk="+primary_key);
				});
	$('.copy #copy_record_form').submit(function(event)
				   {
				       event.preventDefault();
				       $.post("copy_write.php",$(this).serialize(),function(data)
					     {
						 window.opener.location.reload();
						 $('div.notice').html(data).hide().fadeIn('fast');
					     });
				   });

      $('.update_form').submit(function(event)
				   {
				       event.preventDefault();
				       $.post("update.php",$(this).serialize(),function(data)
					     {
						 //window.location.reload();
						 $('div.notice').html(data).hide().fadeIn('fast');
					     });
				   });
      $('table#results .field').blur(function()
					    {
						
						$.post("update.php",$(this).parents('td').siblings('form.update_form').serialize(),function(data)
						{
						 //window.location.reload();
						     $('div.notice').html(data).hide().fadeIn('fast');
						});
					    });
      $('.new_button').click(function()
			     {
				 $('.new').fadeIn('fast');
				 
			     });
      $('.new').hide();
      $('.edit_button').click(function()
			      {
				  primary_key = $(this).parents('tr').attr('id');
				  window.open("edit.php?pk="+primary_key);
			      });
     $('.edit #edit_record_form').submit(function(event)
				   {
				       event.preventDefault();
				       $.post("update.php",$(this).serialize(),function(data)
					     {
						 window.opener.location.reload();
						 $('.notice').html(data).hide().fadeIn('fast');
					     });
				   });

     // $('.edit').hide();
      $('#new_record_form').submit(function(event)
				   {
				       event.preventDefault();
				       $.post("write.php",$(this).serialize(),function(data)
					     {
						 $('div.notice').html(data).fadeIn('fast');
					     });
				   });
      /* $('.print_button').click(function()
			       {
				   primary_key = $(this).parents('tr').attr('id');
				   window.open("print.php?pk=" + primary_key);
				   });*/
      // The print function has been delegated to private Javascript, as each template is different

      $('#results tr').hover(function(event)
			     {
				 $(this).children('td').children('.action_button').show();
				 $(this).addClass('active');
			     },
			     function()
			     {
				 $(this).children('td').children('.action_button').hide();
				 $(this).removeClass('active');
			     });


      $('div.new input,div.edit input, div.new select,div.edit select, div.new textarea,div.edit textarea').focus(function()
					      {
						  $(this).addClass('active');
					      });
      $('div.new input,div.edit input, div.new select,div.edit select, div.new textarea,div.edit textarea').blur(function()
					      {
						  $(this).removeClass('active');
						  });
      $('input.selected').click(function()
				    {
					primary_key = $(this).parents('tr').attr('id');
				
					if ($(this).attr('checked')=='true') 
					    {
						deselect_this_record(primary_key);
						
					    }
					else
					    {
						select_this_record(primary_key);
						
					    }
				    });
      function select_this_record(primary_key)
      {
	  $.get("select-this-record.php",{pk: primary_key, action: 1}, function(data)
		{
		    
		});
      }
      
      function deselect_this_record(primary_key)
      {
	  $.get("select-this-record.php",{pk: primary_key, action: 0}, function(data)
		{
		    
		});
      }
      $('input#select_all').click(function()
				  {

				      if ($(this).attr('checked')==true) // To be selected
					  {
					      $('table#results tr').each(function()
									 {
									     select_this_record($(this).attr('id'));
									 });
					      $('input.selected').attr('checked',true);
					  }
				      else
					  {
					      $('table#results tr').each(function()
									 {
									     deselect_this_record($(this).attr('id'));
									 });
					      
					      $('input.selected').attr('checked',false);
					  }
				  });
        
  });
