<?php
session_start();
extract($_SESSION);

echo '<div class="new" style="';
	  if ($_GET['new'])
	    echo 'display:block';
	  else
	    echo 'display:none';
	  echo '">',$_GET['new'],'<div class="close"><a href="',$_SERVER['PHP_SELF'],'"><img src="images/close.png" alt="Close" title="Close"></a></div>
	  <form name="new_record_form" id="new_record_form" method="POST" action="write.php">';
	  $i = 0; 
	  for ($i=0;$i<count($fields);$i++)
	      {
		
		  echo '<div class="field ', $fields[$i]->name,'">'; // The div containing the entry
		  echo '<div class="new_label"><label class="'; // The label for the entry
		  if ($primary_key==$fields[$i]->name) echo "primary_key"; // If this field is primary key, add it to the lass
		  echo '">',$fields[$i]->name,'</label></div>';
		  
		  echo '<div class="new_value">'; // The div containing the box
		  if ($defaults[$fields[$i]->name]) // If this field has a default value
		      {
			  $def_this_field = $defaults[$fields[$i]->name];
			  $def_table = $def_this_field['table'];
			  $def_field = $def_this_field['field'];
			  $def_foreign_key = $def_this_field['foreign_key'];
			  $def_value = $def_this_field['value'];
			  $sql = "SELECT `$def_field` FROM `$def_table` WHERE `$def_foreign_key` = '$def_value'";
			  $def_res=$mysqli->query($sql);
			  $def_row = $def_res->fetch_row(); // Fetch the default value from the parameters
		      }

		// Construct the type of input box		  		 
		  if ($fields[$i]->type == $TEXT_FIELD_TYPE) // Text field
		      echo '<textarea ';
		  else if ($opts['refs'][$fields[$i]->name]) // This field is a reference
		      echo '<select ';
		  else
		      echo '<input type="text" ';
		      
	        // Construct the attributes of the input box
		  echo 'title="',
		      $fields[$i]->name,
		      '" name="',
		      $fields[$i]->name,
		      '" class="field ',
		      $fields[$i]->name;
		  
		  if ($fields[$i]->type == $DATETIME_FIELD_TYPE ||
		      $fields[$i]->type == $TIMESTAMP_FIELD_TYPE) // Date time field, add a class to attach the calendar later
		      echo ' date_field ';
		  
		  if ($opts['dropdown'][$fields[$i]->name]) // This fields needs a dropdown box, needs dropdown.js
		    echo '" id="',$fields[$i]->name,'_dropdown'; // Add a '_dropdown' after its id
		  else
		    echo '" id="',$fields[$i]->name;
		    
		  echo '" value="';
			if ($_GET['new'] && $_GET[$fields[$i]->name]) // If the address bar has given the 'new' parameter and default value for a field
			{
			    echo $_GET[$fields[$i]];
			}
			else // If this has a default value set by $opts parameters
			    echo ($def_row) ? $def_row[0] : "";
		      echo '">';
		  
		  if ($fields[$i]->type == $TEXT_FIELD_TYPE) // This is a text field
		  {
		      echo ($def_row) ? $def_row[0] : "";
		      echo '</textarea></div>';
		   }
		   
		  elseif ($opts['refs'][$fields[$i]->name]) // This is a reference
		      {
			  $ref = $opts['refs'][$fields[$i]->name]; // Construct the select box from parameters supplied by foreign key, table and display field
			  if ($ref['foreign_key'])
			      {
				  $ref_sql = "SELECT ". $ref['foreign_key'] . ", " . $ref['display_field'] . " FROM " . $ref['table'];
				  $ref_results=$mysqli->query($ref_sql);
				  echo '<option value=""></option>';
				  while($ref_row=$ref_results->fetch_assoc())
				      {
					  echo '<option value="',$ref_row[$ref['foreign_key']],'">',$ref_row[$ref['display_field']],'</option>';
				      }
				  echo '</select></div>';
			      }
			  else // For enum fields specified in $opts['refs'], which have no table associated
			      {
				  foreach ($ref as $val)
				      {
					  echo '<option value="',$val,'">',$val,'</option>';
				      }
			      				  echo '</select></div>';	

			      }

		      }
		  else
		      echo '</input></div>';
		  echo '</div>';
		  unset($def_row);
	      }

	  echo '<input type="image" src="images/yes.png" id="Add" alt="Add"></input></form></div>';
?>