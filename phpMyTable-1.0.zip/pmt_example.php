<html>

<head>
  <title>phpMyTable: Example</title>
</head>

<body>
  <?php
  session_start();
  require_once($_SERVER['DOCUMENT_ROOT'].'/apps/pmt/phpMyTable.class.php'); // Place the directory path to the phpMyTable.class.php here
  ini_set('display_errors',0); // Set 1 for debugging
?>
 
  <h1>Example table of users</h1>
  <p>This is a demo table; hover over each record for  details. See the source of this page (in PHP) for documentation</p>
<?php

// Configuration
$opts = array();
$opts['host'] = "localhost";
$opts['db'] = "pmt_test";
$opts['username'] = "username";
$opts['password'] = "password";
$opts['table'] = 'users';
$opts['primary_key'] = 'userid';
$opts['results_per_page'] = 10;
$opts['filter'] = null; // The WHERE clause
$opts['readonly'] = false;
$opts['readonly_fields'] = array('userid');
$opts['refs'] = array (
    'sex' => array('m','f'), // An ENUM field
	'type' => array(
	    'table' => 'types',
	    'foreign_key' => 'typeid',
		'display_field' => 'name'
	) // Foreign key
);
$opts['sort']= array('firstname' => 'ASC'); // ASC or DESC, fields in sequence of sort
$opts['dropdown'] = array( // Using the dropdown project, for foreign keys
    'firstname' => array( 
	'table' => 'users', // maybe same or different table, where you want to draw data from
	    'fields' => array('firstname','lastname'), // fields to search for
	    'display_fields' => array('firstname','lastname'),
	    'fillup_field' => 'firstname', // to fill up the value of the box
	    'primary_key' => 'userid', // of the related table
	    'display_in_table_field' => null,
	    'multiple' => 1,  // whether many textboxes will share this dropdown
	    'search_only' => 1, // to search only = 1, to fillup the box from searched values = 0
    ),
    'cityid' => array(
	'table' => 'cities',
	    'fields'=> array('name'),
	    'display_fields'=>array('cityid','name'),
	    'fillup_field' => 'cityid',
	    'display_in_table_field' => 1,
	    'multiple' => 1,
	    'search_only' => 0)

);
$opts['input_suggestions'] = array(
    'userid' => 'Auto generated', 
	'zipcode' => 'Numbers only'
    );
$opts['defaults']=array('sex' => array ('value' => 'm'), 'type' => array('value' => 'normal')); // Default values
$opts['multiple_refs'] = array(); // If primary key of this table is entered several times in some other table, i.e. one to many relation
$opts['display_ref_fields'] = array(); // If a field is a foreign key to other table, display the value of the foreign referenced field in the next col; however, no search function yet
$opts['click_fields'] = array('cityid' => array('click_table_page' => 'cities.php','click_primary_key'=>'cityid')); // If a field is a foreign key to other table, clicking the fields takes you to the value in the foreign table; the other page also needs to be made by phpMyTable, i.e. cities.php
$opts['input_validations'] = array(
    'zipcode' => array('numeric', 'required'),
	'firstname' => array('character','capital','required'),
	'lastname' => array('character','capital'),
	'cityid' => array('required')
);
$opts['input_max_lengths'] = array('zipcode'=>'6');
$opts['invisible'] = array (); // Fields you don't want to show
$opts['initial_focus'] = 'firstname';
$opts['relative_width'] = array('firstname' => 1,'lastname'=>2);
$opts['max_col_header_length'] = 5; // Columns headers abbreviation
$opts['text_fields'] = array('description');
// Do not edit below this if you just want to use the software
$_SESSION['opts']=$opts;
$pmt = new phpMyTable($opts);
?>
</body></html>
