<html>

<head>
  <title>phpMyTable: Example</title>
</head>

<body>
  <?php
  session_start();
  require_once($_SERVER['DOCUMENT_ROOT'].'/apps/pmt/phpMyTable.class.php'); // Place the directory path to the phpMyTable.class.php here
  ini_set('display_errors',0); // Set 1 for debugging
?>
 
<h1>Example table of users</h1>
<?php

// Configuration
$opts = array();
$opts['host'] = "localhost";
$opts['db'] = "pmt_test";
$opts['username'] = "username";
$opts['password'] = "password";
$opts['table'] = 'cities';
$opts['primary_key'] = 'cityid';
$opts['results_per_page'] = 10;
$opts['filter'] = null; // The WHERE clause
$opts['readonly'] = false;
$opts['readonly_fields'] = array('userid');

// Do not edit below this if you just want to use the software
$_SESSION['opts']=$opts;
$pmt = new phpMyTable($opts);
?>
</body></html>
