# phpMyTable

Makes a live editable table format in a browser from a MySQL table

1. Extract the zip somewhere inside the 'www' folder
2. Edit index.php; enter name of  host, datatabse, username, password and table
3. Run localhost/pmt (or whatever your directory structure is)
4. Copy index.php to create as many pages for tables
