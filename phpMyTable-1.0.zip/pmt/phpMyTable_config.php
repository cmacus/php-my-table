<!-- phpMyTable_config.php begins -->
<!-- Common setup for all phpMyTable pages -->

<?php

// Settings
global $DATE_FORMAT,$PMT_DIR_SERVER,$PMT_DIR_CLIENT,$DROPDOWN_APP_PATH_CLIENT,$DROPDOWN_APP_PATH_SERVER;
$PMT_DIR_SERVER=$_SERVER['DOCUMENT_ROOT'].'/apps/pmt';
$PMT_DIR_CLIENT = '/apps/pmt';
$DROPDOWN_APP_PATH_SERVER = '/apps/dropdown'; // Need to specify where the Dropdown.js file is
$DROPDOWN_APP_PATH_CLIENT = 'http://localhost/apps/dropdown';

$DATE_FORMAT = file_get_contents($PMT_DIR_SERVER."/DATE_FORMAT");

require_once('create_select_box_from_db.php'); // creates a select box from a database, table and given field

// Error reporting
//ini_set('display_errors',1);
?>

<script type="text/javascript">
<!--

// Declare all settings
PMT_DIR_CLIENT = '<?php echo $PMT_DIR_CLIENT ?>';
PMT_DIR_SERVER = '<?php echo $PMT_DIR_SERVER ?>';
DROPDOWN_APP_PATH_SERVER = '<?php echo $DROPDOWN_APP_PATH_SERVER ?>';
DROPDOWN_APP_PATH_CLIENT = '<?php echo $DROPDOWN_APP_PATH_CLIENT ?>';

-->
</script>

<!-- Jquery -->
<script type="text/javascript" src="<?php echo $PMT_DIR_CLIENT ?>/scripts/jquery.js"></script>

<!-- Optional, not yet implemented -->
<link rel="stylesheet" type="text/css" href="<?php echo $PMT_DIR_CLIENT ?>/styles/mobile.css" media="only screen and (max-width: 480px)" />

<!-- Stylesheet for the phpMyTable project -->
<link rel="stylesheet" type="text/css" href="<?php echo $PMT_DIR_CLIENT ?>/styles/phpMyTable.css" media="screen and (min-width: 481px)" />

<!-- The dropdown project stylesheet -->
<link rel="stylesheet" href="<?php echo $DROPDOWN_APP_PATH_CLIENT ?>/dropdown.css"/>

<!-- Script for phpMyTable project -->
<script src="<?php echo $PMT_DIR_CLIENT ?>/scripts/phpMyTable.js"></script>

<!-- Script for the dropdown project-->
<script type="text/javascript" src="<?php echo $DROPDOWN_APP_PATH_CLIENT ?>/dropdown.js"></script>

<!-- JSCalendar -->
<style type="text/css">@import url(<?php echo $PMT_DIR_CLIENT ?>/jscalendar/calendar-mac.css);</style>
<script type="text/javascript" src="<?php echo $PMT_DIR_CLIENT ?>/jscalendar/calendar.js"></script>
<script type="text/javascript" src="<?php echo $PMT_DIR_CLIENT ?>/jscalendar/lang/calendar-en.js"></script>
<script type="text/javascript" src="<?php echo $PMT_DIR_CLIENT ?>/jscalendar/calendar-setup.js"></script>

<!-- Notice -->
<div class="notice dont_print"><div id="notice_text"></div></div>

<!-- Dropdown div -->
<div id="fillup" class="dont_print"></div>

<!-- phpMyTable_config.php ends -->
