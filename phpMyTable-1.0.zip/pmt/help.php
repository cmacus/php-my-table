<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-15">
<title>Citrus: Help</title>
</head>

<body>
<?php
require_once('phpMyTable_common.php');
?>
<h1>Help</h1>
<h2><a name="path">Configuring MySQL server</a></h2>
After you have set up the database
<ol>
<li>From 'Comupter', open C: drive -> wamp installation -> bin -> mysql -> mysql<em>version number</em> -> bin; now open the MySQLInstanceConfig program</li>
<li>Click 'standard configuration'</li>
<li>Set a root password, which you SHOULD NOT FORGET</li>
<li>Next tick the checkbox 'add mysql executables to system path'</li>
<li>Finish the wizard</li>
</ol>
<h2>Importing data from CSV file</h2>
<p>Many analysers export a day's results in CSV format. The file can be uploaded to the server. The first time it is uploaded, it creates the table structre (i.e. Date, Name, Age, Sugar, Urea, Creat etc).</p>
<h3>Data type conversion issues</h3>
<p>Any field in the CSV file which contains the word 'name' is converted a text field, and any 'date' into datetime field. Every other field (i.e. urea, creat) is given a 'float' (i.e. decimal value) type as default.
<br/>Any 'date' field needs to be either in these formats: 2012-03-21, 21-Mar-2012, 21-Mar-12, 21-03-2012. Otherwise it might not be recognized as a date.</p>
<h3>A way around with a catch</h3>
<p>If your machine can not export in this format, you can <a href="change_date_format.php?format=text">manually change the date format to plain text</a> (which will disable sorting by date). You can also <a href="change_date_format.php?format=date">revert back the change</a>. However, this will only work if you are importing for the FIRST TIME, because the data format can not be changed later. Be sure that you are not changing the format of an already imported table.</p>
<h2><a name="opd">OPD procedure</a></h2>
<ol>
  <li>Click 'Register new patient'; follow guidelines in the form</li>
  <li>The 'New OPD Appointment'</li>
</ol>
<hr>
<address>Design: Parikshit Sanyal &lt;cmacus@gmail.com&gt;</address>
<!-- hhmts start -->Last modified: Wed Dec  5 09:28:46 IST 2012 <!-- hhmts end -->
</body> </html>
