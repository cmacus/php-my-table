<?php
function create_select_box_from_db($host,$db,$username,$password,$table,$field,$value_field,$select_box_id, $select_box_name,$select_box_class)
{
    $dsn = "mysql:host=".$host.";dbname=".$db.";";
	try
	{
	    $dbh = new PDO($dsn, $username, $password);
	}
	catch (PDOException $e)
	{
	    echo 'Connection failed: ' . $e->getMessage();
	}

    $res = $dbh->prepare("SELECT $value_field, $field FROM $table");
    $res->execute();
    echo '<select name="',$select_box_id,'" class="',$select_box_class,'" id="',$select_box_id,'" name="',$select_box_name,'">';
    while ($row = $res->fetch(PDO::FETCH_ASSOC))
    {
        echo '<option value="',$row[$value_field],'">',$row[$field],'</option>';
    }
    echo '</select>';
}
?>