<?php
session_start();
extract($_GET);
$_SESSION['selected_items'][$pk]=$action;
?>


