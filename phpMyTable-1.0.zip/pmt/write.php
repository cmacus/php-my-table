<?php
session_start();
extract($_SESSION);
extract($opts);
$table=$_GET['current_table'];
$dsn = "mysql:host=".$host.";dbname=".$db.";";
	try
	{
	    $dbh = new PDO($dsn, $username, $password);
	    $dbh->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
	}
	catch (PDOException $e)
	{
	    echo<<<END
{	
    "row_id" : "",
    "result" : "Connection failed: {$e->getMessage()}"
}
END;
	}
$sql = "INSERT INTO `$table` SET ";

foreach($_GET as $key => $value)
{
    if ($key != 'current_table')
    {
		if ($value)
		{
	    	$sql .= "`$key`='$value',";
		}
    }
}
$sql=substr($sql,0,-1);

try
{
	$res=$dbh->prepare($sql);
	$res->execute();
	$row_id=$dbh->lastInsertId();
	echo<<<END
{	
    "row_id" : "{$row_id}",
    "result" : "{$res->rowCount()} record inserted"
}
END;
}
catch (PDOException $e)
{
	echo<<<END
{
	"row_id" : "{$row_id}",
	"result" : "{$e->getMessage()} {$sql}"
}
END;
}
?>
