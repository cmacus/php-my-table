<?php
class phpMyTable
{
    
    // Generates a HTML editable table interface from a mysql table, given $opts as argument
    public $search_array;
    public $ref_fields_option_list = array();
    
    public function create_dual_text_box($value,$display,$attrs,$max_length)
    {
	// Create a text box with value, and a label with the display value, of max_length; the atttrs will be added
	echo '<div class="dual_text_box"><input ',str_replace('class="','class="dual_text_box_value ',$attrs),' value="',$value,'"></input><span class="dual_text_box_display" title="',$display,'">';
	if (strlen($display) > $max_length)
	    echo substr($display,0,$max_length-3).'...';
	else
	    echo $display;
	echo '</span></div>';
    }
    
    // Make PDO object
    function __construct($opts)
    {
	require_once('phpMyTable_config.php'); //Must have included this file somewhere before
	global $PMT_DIR_SERVER,$PMT_DIR_CLIENT;
	extract($opts);
	$_SESSION['username'] = $username;
	$_SESSION['password'] = $password;
	$_SESSION['host'] = $host;
	$_SESSION['db'] = $db;
    	// Make connection
    	$dsn = "mysql:host=".$host.";dbname=".$db.";";
    	try
    	{
    	    $dbh = new PDO($dsn, $username, $password);
    	}
    	catch (PDOException $e)
    	{
    	    echo 'Connection failed: ' . $e->getMessage();
    	}
    	global $TEXT_FIELD_TYPE, $TIMESTAMP_FIELD_TYPE, $DATETIME_FIELD_TYPE, $MAX_LENGTH_DISPLAY_FIELD_IN_DUAL_TEXT_BOX,$DATE_FORMAT;
    	if (isset($_POST[$primary_key]))
    	    // Update the row with primary key from POST
    	    $opts['data_array']=$_POST;

    	$current_table = $opts['table'];
    	$current_primary_key = $opts['primary_key'];

    	// Reset function
    	if (array_key_exists('reset',$_GET)) // Clear and sort and search information
    	{
    	    unset($_SESSION['sort_sql'],$_SESSION['search_sql'],$_SESSION['sort'],$_SESSION['selected_items']);
    	}

    	/* Global update
    	if ($_SESSION['selected_items'])
    	{
            if (count($_SESSION['selected_items']) > 0) // If some items were checked
            {
		extract($_POST);
		extract($opts);
		foreach ($_SESSION['selected_items'] as $key => $value)
		{
    		    if (isset($value))
		    {
			try
			{
			    $global_update_sql="UPDATE `$table` SET `$global_update_field` ='$global_update_value' WHERE `$primary_key` = '$key'";
			    $res_global_update = $dbh->prepare($global_update_sql);
			    $res_global_update->execute();
			}
			catch(PDOException $e)
			{
			    echo $e->getMessage();
			}
		    }
		    unset($_SESSION['selected_items']);
		}
            }
	}*/
	
    	// Search function
	// First, find ref fields and preform a list of options

    	if (array_key_exists('search',$_GET))
    	{
    	    $opts['search']=array_slice($_GET,1);
    	    $table=$current_table;
    	    unset($_SESSION['page_number']);
    	    $search_sql=$_SESSION['search_sql'];
    	    global $search_array;
    	    foreach($opts['search'] as $key => $value)
    	    {
    		if ($value) // Filter only fields that are being searched for
    		    $search_array[$key] = $value;
    	    }
	    
    	    if (!count($search_array))
    	    {
    		unset($_SESSION['search_sql']);
    		return;
    	    }
	    
    	    $search_sql = " ";
    	    $search_field_count = count($search_array);
	    
	    $i=0;

    	    foreach ($search_array as $key => $value)
    	    {
    		if (array_key_exists($key,$refs)) // If it is a reference field do an exact search
    		    $search_sql .= " `$key` = '$value' ";
    		else
    		    $search_sql .= " `$key` REGEXP '$value' ";
		$i++;
    		if ($i < $search_field_count)
    		    $search_sql .= " AND ";
		
	    }
    	    $_SESSION['search_sql'] = $search_sql;
    	}
	
    	// Store the details of the present page
    	echo '<div id="page_details" class="hidden dont_print">';
    	foreach($opts as $key=>$value)
    	{
    	    echo '<span id="',$key,'">',$value,'</span>';
    	}
    	echo '</div>';
	echo '<div id="current_table" class="hidden dont_print">',$current_table,'</div><div id="current_primary_key" class="hidden dont_print">',$current_primary_key,'</div>';

	// Initiate connection
    	global $TEXT_FIELD_TYPE, $DATETIME_FIELD_TYPE, $TIMESTAMP_FIELD_TYPE;

    	// Start building sql
    	$sql = "SELECT * FROM `".$opts['table']."`";
	
    	// If a primary key has been specified in URL, find it and stop
    	if (array_key_exists('pk',$_GET))
    	{
    	    $sql .= " WHERE `".$opts['primary_key']."` = '".$_GET['pk']."'";
    	}
	
    	// Search & filter
    	if (isset($_SESSION['search_sql']))
	{
	    
    	    if (isset($opts['filter']))
    		$sql .= " WHERE ".$_SESSION['search_sql']." ".$opts['filter'];
    	    else
    		$sql .= " WHERE ".$_SESSION['search_sql'];
	}
    	else
	{
    	    if ($opts['filter'])
    		$sql .= " WHERE ".$opts['filter'];
	}
    	// Sort
    	if (isset($_GET['sort']))
    	{
    	    $sort_key=$_GET['sort'];
    	    if ($_SESSION['sort'][$sort_key]) // Sort on this field exists
    	    {
    		if ($_SESSION['sort'][$sort_key] == 'ASC')
    		    $_SESSION['sort'][$sort_key] = 'DESC'; // Reverse it
    		else
    		    $_SESSION['sort'][$sort_key] = 'ASC'; // Reverse it
    	    }
    	    else
    		$_SESSION['sort'][$sort_key] = 'ASC';
    	    if ($_SESSION['sort'])
    	    {
    		$sort_sql = " ORDER BY ";
    		$sort_field_count = count($_SESSION['sort']);
    		$i=1;
    		foreach($_SESSION['sort'] as $sort_field => $direction)
    		{
    		    $sort_sql .= "`$sort_field` $direction";
    		    if ($i == $sort_field_count)
    			$sort_sql .= " ";
    		    else
    			$sort_sql .= ", ";
    		    $i++;
    		}
    		$_SESSION['sort_sql'] = $sort_sql;
    	    }
    	    if ($_SESSION['sort_sql']) // If user has clicked on a sort field before
    	    {
    		$sql .= $_SESSION['sort_sql'];
    	    }
	}
    	elseif (count($opts['sort']) > 0) // If this is the first time page is loading and sort order is set in opts
    	{
    	    $sql .= " ORDER BY ";
    	    foreach ($opts['sort'] as $key=>$value)
    	    {
    		$sql .= " `$key` $value,";
    	    }
	    
    	    $sql = substr($sql,0,-1); // Remove trailing comma
    	}
	
	// If a primary key has already been received by a GET request, fetch that record only
    	if (!empty($_GET[$opts['primary_key']]))
    	{
    	    $key = $_GET[$opts['primary_key']];
    	    $sql = "SELECT * FROM `".$opts['table']."` WHERE `".$opts['primary_key']."` = '$key'";
    	}
        $count_sql = str_replace('SELECT *','SELECT COUNT(*)',$sql);
    	echo '<div class="sql_query dont_print">',$sql,'</div>';

    	// Pagination
	$count_result = $dbh->prepare($count_sql);
	$count_result->execute();
	$count_row = $count_result->fetch(PDO::FETCH_NUM);
	$number_of_results = $count_row[0];
	
    	//Determine results per page
    	if (isset($_POST['results_per_page']))
    	{
    	    $_SESSION['results_per_page'] = $_POST['results_per_page'];
    	}
	
    	$results_per_page = $_SESSION['results_per_page']?$_SESSION['results_per_page']:10;
	echo $result_per_page;
	$number_of_pages = ceil($number_of_results/$results_per_page);
	if (isset($_GET['page_number'])) // Previously clicked by a page link
	{
            if ($_GET['page_number'] > $number_of_pages)
		$page_number = 1;
            else
		$_SESSION['page_number'] = $_GET['page_number'];
	}
	
	if (isset($_SESSION['page_number']))
	{
	    if ($_SESSION['page_number'] > $number_of_pages)
	    {
		if ($number_of_pages == 0)
		    $page_number = 0;
		else
		    $page_number=1;
	    }
	    else
		$page_number = $_SESSION['page_number'];
	}

	else
	{
	    if ($number_of_pages == 0)
		$page_number = 0;
	    else
		$page_number=1;
	}
	
    	echo '<div class="paginate dont_print">';
    	echo 'Show <form id="results_per_page_form" method="POST" action="',$_SERVER['PHP_SELF'],'"><input type="text" value="',$results_per_page,'" name="results_per_page"/> results per page. </form>';
    	echo '<strong>',$number_of_results,'</strong> Records. Page ', $page_number, ' of ', $number_of_pages, ' ';
    	echo ($page_number == 1) ? ' ' : '<a href="'.$_SERVER['PHP_SELF'].'?page_number='.($page_number-1).'"><span class="page_link"><img src="'.$PMT_DIR_CLIENT.'/images/prev.png"/></span></a>';
    	echo ' <select name="page_numbers" class="page_numbers">',
    	    '<option value="" selected>Go to</option>';
    	for ($i=1;$i<=$number_of_pages;$i++)
    	{
    	    echo '<option value="',$i,'">',$i,'</option>';
    	}
    	echo '</select> ';
    	echo ($page_number == $number_of_pages) ? ' ' : ' <a href="'.$_SERVER['PHP_SELF'].'?page_number='.($page_number+1).'"><span class="page_link"><img src="'.$PMT_DIR_CLIENT.'/images/next.png"></span></a> ';
	
    	echo ' <a class="new_button dont_print" id="new_button_',$table,'" href="javascript:void(0)"><span class="new_button" id="new_button_top_"',$table,'"><img src="'.$PMT_DIR_CLIENT.'/images/new.png" alt="New record"></span></a> <span class="reset_button"><a href="',$_SERVER['PHP_SELF'],'?reset=1"><img src="'.$PMT_DIR_CLIENT.'/images/reset.png"/></a></span> ';
    	echo '</div>';
    	$low_limit = ($page_number-1) * $results_per_page;
    	if (!$page_number) $low_limit=1;
    	$sql .= " LIMIT $low_limit, $results_per_page ";
	
    	// Get table data
	
	$dbh->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
	$data_results = $dbh->prepare($sql);
	$data_results->execute();
	
    	$col_count = $data_results->columnCount();
    	$fields = array();
    	for($i=0; $i<$col_count; $i++)
    	{
    	    $fields[$i] = $data_results->getColumnMeta($i);
    	}
    	$row = $data_results->fetch(PDO::FETCH_NUM);

    	
	// Determine position of primary key
    	for($i=0;$i<count($fields);$i++)
    	{
    	    if ($fields[$i]['name'] == $opts['primary_key'])
    		$position_of_primary_key = $i;
    	}
	
    	// The 'show' div
	echo '<div id="show"><a href="javascript:void(0)"><div class="close_button dont_print" id="close_show_button"><img src="'.$PMT_DIR_CLIENT.'/images/close.png" alt="Close" title="Close"></div></a><div id="content"></div></div>';
	
	// The new record form
	echo '<div id="new" class="dont_print" style="';
    	if (array_key_exists('new',$_GET)) // If 'new' is there in the URL
    	    echo 'display:block';
    	else //Hide it
    	    echo 'display:none';
    	echo '">';
    	echo '<div class="new_left"><div class="close_button dont_print"><a href="javascript:void(0)"><img src="'.$PMT_DIR_CLIENT.'/images/close.png"></a></div>';
    		// Common form template for new and edit form
    	require('common_form.php');
    	echo '<div><label id="insert_wait"></label> Inserted row id <label id="row_id"></label>';
	$print_path = isset($opts['custom_print_path']) ? $opts['custom_print_path'] : $PMT_DIR_CLIENT.'/print.php';
	echo '<span id="print_record"><a class="bright_link" href="',$print_path,'?table=',$current_table,'" target="_blank">Print</a></span></div>';
    	echo '<div id="multiple_entry_buttons">'; // Construct entry for multiple foreign_key fields
    	foreach($opts['multiple_refs'] as $ref)
    	{
    	    echo<<<END
<div class="multiple_entry_button"><a class="fancy_button" href="javascript:void(0)" onclick="open_multiple_entry_table('{$ref['table']}','{$ref['foreign_key']}','{$ref['primary_key']}')"> Add from {$ref['table']}</a></div>
END;
    	}
    	echo '</div></div><div class="new_right"></div></div>';
	
    	// Begin table
    	echo '<table id="results">';
	
    	// Count relative width
	if (isset($opts['relative_width']))
    	    foreach($opts['relative_width'] as $key=>$value)
    		$sum += $value;
	
    	// Columns
    	foreach ($fields as $field)
    	{
    	    echo '<col id="',$field['name'],'" ';
    	    if (isset($opts['relative_width'][$field['name']]))
    	    {
    		$width_percent = floor($opts['relative_width'][$field['name']] * 100/ $sum);
    		echo 'style="width:',$width_percent,'%"';
    	    }
    	    echo '>';
    	}
	
    	// Header row
	if (!array_key_exists('show_labels',$opts))
	    {
    		echo '<thead><tr><th class="dont_print"></th>';
    		foreach($fields as $field)
    		{
    		    if (!in_array($field['name'],$opts['invisible']))
    		    {
    			echo '<th scope="col" title="Sort on this field: ', $field['name'],'" class="',$field['name'];
    			if ($field['name'] == $opts['primary_key']) echo " primary_key ";
    			echo '" ';
    			if (isset($opts['relative_width'][$field['name']]))
    			{
    			    $width_percent = floor($opts['relative_width'][$field['name']] * 100/ $sum);
    			    echo 'style="width:',$width_percent,'%"';
    			}
    			echo '><a href="',
    			    $_SERVER['PHP_SELF'],
    			    '?sort=',
    			    $field['name'],
    			    '">';
    			if (isset($opts['max_col_header_length']))
			{
    			    if (strlen($field['name']) > $opts['max_col_header_length'])
    				echo substr($field['name'],0,$opts['max_col_header_length']).'...';
    			    else
    				echo $field['name'];
			}
    			else
    			    echo $field['name'];
    			echo '</a>';
			if (isset($_SESSION['sort'][$field['name']])) // Sort on this field exists
    			{
    			    if ($_SESSION['sort'][$sort_key] == 'ASC')
    				echo '↓';
    			    else
    				echo '↑';
    			}
			echo '</th>';
		    }
		
    	    }
    	}
    	echo '<th/>';
    	echo '</tr></thead>';
	
    	// Body of table
    	echo '<tbody>';
	
    	// Search row
	if (!array_key_exists('show_labels',$opts))
	{
    	    echo '<tr class="search dont_print"><form class="search_form" action="',$_SERVER['PHP_SELF'],'" method="GET">
<input type="hidden" name="search" value="1">';
    	    global $search_array;
    	    echo '<td><input type="checkbox" id="select_all" class="dont_print"></input></td>';
    	    for ($i=0;$i<count($fields);$i++)
    	    {
		if (!in_array($fields[$i]['name'],$opts['invisible']) && !in_array($fields[$i]['name'],$opts['show_labels']))
		{
    		    echo '<td>';
    		    if (isset($opts['refs'][$fields[$i]['name']]))
    			echo '<select ';
    		    else
    			echo '<input type="text" ';
    		    echo 'class="search ';
    		    if ($fields[$i]['native_type'] == 'TIMESTAMP' || $fields[$i]['native_type'] == 'DATE' || $fields[$i]['native_type'] == 'DATETIME')
    			echo ' date_field ';
    		    echo  $fields[$i]['name'],
    			'" name="',
    			$fields[$i]['name'],
    			'" placeholder="Search by ',
    			$fields[$i]['name'],
    			'" id="search_',
    			$fields[$i]['name'],
    			'" value="',
    			$search_array[$fields[$i]['name']],
    			'">';
		    
		    // Create preformed list for select boxes
		    if (isset($opts['refs'][$fields[$i]['name']]))
    		    {
    			$ref = $opts['refs'][$fields[$i]['name']];
    			if (array_key_exists('foreign_key', $ref)) // This reference points to a foreign key in another table
    			{
			    
    			    $ref_sql = "SELECT `". $ref['foreign_key'] . "`, `" . $ref['display_field'] . "` FROM `" . $ref['table']."`";
    			    $ref_results = $dbh->prepare($ref_sql);
    			    $ref_results->execute();
    			    $str = '<option value=""></option>';
    			    while($ref_row=$ref_results->fetch(PDO::FETCH_ASSOC))
    			    {
    				if ($search_array[$fields[$i]['name']] == $ref_row[$ref['foreign_key']])
    				    $str .= '<option selected ';
    				else
    				{
    				    $str .= '<option ';
    				}
    				$str .= ' value="'.$ref_row[$ref['foreign_key']].'">'.$ref_row[$ref['display_field']].'</option>';
    			    }
			    echo $str;
    			    echo '</select>';
    			}
    			else // The values of the reference has been provided in the PHP page itself
    			{
    			    $str = '<option value=""></option>';
    			    foreach ($ref as $val)
    			    {
    				$str .= '<option value="'.$val.'">'.$val.'</option>';
    			    }
			    echo $str;
    			}
    		    }
    		    else
    			echo '</input>';
    		    echo '</td>';
		    $ref_fields_option_list[$fields[$i]['name']] = $str;
		}
    	    }
    	echo '<td><input type="submit" alt="Search" value="Search" id="search_button"></input></td>';
    	echo '</form>';
    	echo '</tr>';
	}
	
    	// Begin main  body
    	    $rowcount=0;
    	    $colcount=0;
    	    while ($row)
    	    {
		    $rowcount++;
    	    echo '<tr class="result display_mode" id="',$row[$position_of_primary_key],'">';

	    // Begin update form 
	    echo '<form action="update.php" method="POST" class="update_form">';
    	    echo '<input type="hidden" name="current_table" value="',$current_table,'"/>';
    	    echo '<input type="hidden" name="current_primary_key" value="',$current_primary_key,'"/>';
    	    echo '<td class="dont_print"><input type="checkbox" class="selected"></input></td>';
    	    $i = 0;
    	    for ($i=0;$i<count($fields);$i++)
    	    {
		if (!in_array($fields[$i]['name'],$opts['invisible']))
		{
		    $row[$i] = htmlspecialchars($row[$i]); // Remove HTML
		    if ($opts['readonly']==true)
		    {
			if (isset($opts['date_format']))
			    $DATE_FORMAT = $opts['date_format'];
			else
			    $DATE_FORMAT = file_get_contents('DATE_FORMAT');

			if(array_key_exists('show_labels',$opts))
			    {
				if ($row[$i]!=0 && $row[$i]!='NA' && $row[$i]!=null)
				{
				    echo '<td>';
				    if (in_array($fields[$i]['name'],$opts['show_labels']))
					echo '<label class="display_label">',$fields[$i]['name'],'</label>';
				    if ($fields[$i]['native_type'] == 'TIMESTAMP' || $fields[$i]['native_type'] == 'DATE' || $fields[$i]['native_type'] == 'DATETIME')
				    {
					echo date_format(date_create($row[$i]),$DATE_FORMAT);
				    }
				    else
					echo $row[$i];
				    echo '</td>';
				}
			    }
			    else
			    {
				echo '<td>';
				if ($fields[$i]['native_type'] == 'TIMESTAMP' || $fields[$i]['native_type'] == 'DATE' || $fields[$i]['native_type'] == 'DATETIME')
				{
				    echo date_format(date_create($row[$i]),$DATE_FORMAT);
				}
				else
				    echo $row[$i];
				echo '</td>';
			    }
		    }
		    else
		    {
    			// Construct the attributes of the box first
			$attrs ='class="field ';
    			if ($fields[$i]['native_type'] == 'TIMESTAMP' || $fields[$i]['native_type'] == 'DATE' || $fields[$i]['native_type'] == 'DATETIME')
    			    $attrs .= 'date_field ';
    			if (isset($opts['click_fields'][$fields[$i]['name']]))
    			    $attrs.= 'click_field ';
    			$attrs.= $fields[$i]['name'].'"';
			// Class attribute ends
			
    			if (isset($opts['click_fields'][$fields[$i]['name']])) // Double clicking this takes to another table
    			{
    			    $attrs.= ' click_table_page="'.$opts['click_fields'][$fields[$i]['name']]['click_table_page'].'" ';
    			    $attrs.= ' click_primary_key="'.$opts['click_fields'][$fields[$i]['name']]['click_primary_key'].'"';
    			}
			
    			// Placeholder attribute begins
    			$attrs.= ' placeholder="'.$fields[$i]['name'];
    			// Placeholder attribute ends
			
    			// Id attribute begins
    			$attrs.= '"id="field_box_'.$rowcount."_".$colcount;
    			// Id attribute ends
			
    			if ($opts['readonly'])
    			    $attrs.= ' readonly ';
			
    			// Name attribute begins
    			$attrs.='" name="'.$fields[$i]['name'].'"';
    			// Name attribute ends
			
    			// Style attribute begins
    			if(isset($opts['relative_width'][$fields[$i]['name']]))
    			{
    			    foreach($opts['relative_width'][$fields[$i]['name']] as $key=>$value)
    				$sum+=$value;
    			}
    			// Style attribute ends
			
    			// Title attribute begins
    			$attrs.= 'title="'.$fields[$i]['name'].': '.$row[$i].'" ';
    			// Title attribute ends
			
			echo '<td class="field_cell ', $fields[$i]['name'], '">';
			$colcount++;
			
			// Make edit label
			echo '<label class="edit_label">',$fields[$i]['name'],'</label>';

			// Make display label
			if ($opts['show_labels'] == true)
			    echo '<label class="display_label">',$fields[$i]['name'],'</label>';
			// Begin making the box
			
			if (isset($opts['refs'][$fields[$i]['name']])) // This is a reference, use preformed option list
			{
			    echo '<select value="',$row[$i],'" ',$attrs,'>',$ref_fields_option_list[$fields[$i]['name']],'</select>';
			}
			else if (array_key_exists($fields[$i]['name'],$opts['dropdown'])) // This field is a dropdown
			{
			    echo '<input type="text" ',$attrs,' value="',$row[$i],'"></input>';;
			}
			else if (in_array($fields[$i]['name'],$opts['text_fields'])) // Text field
			{
			    echo '<textarea ',$attrs,'>';
			}
			else
			    echo '<input type="text"',$attrs,' value="',$row[$i],'">';
			if (in_array($fields[$i]['name'],$opts['text_fields']))
			    echo $row[$i],'</textarea>';
			else
			    echo '</input>';
			echo '</td>';
		    }
		}
	    }
		
	    echo '<td>';
	    if (!$opts['readonly'])
	    {
		echo '
		<span class="action_buttons dont_print">
		<input type="Submit" value="Update" class="update_button"></input></form> <a href="javascript:void(0)" class="edit_button dont_print"><img src="',$PMT_DIR_CLIENT,'/images/edit.png" alt="Edit"></a>';
		$print_path = isset($opts['custom_print_path']) ? $opts['custom_print_path'] : $PMT_DIR_CLIENT.'/print.php';
		$print_path .= '?pk='.$row[$position_of_primary_key].'&current_table='.$current_table;
		echo ' <a href="',$print_path,'" class="print_button" target="_blank"><img src="',$PMT_DIR_CLIENT,'/images/print.png" alt="Print"></a>
		<a href="javascript:void(0)" class="show_button"><img src="',$PMT_DIR_CLIENT,'/images/show.png" alt="Show"></a>
		<a href="javascript:void(0)" class="delete_button"><img src="',$PMT_DIR_CLIENT,'/images/delete.png" alt="Delete"></a></span>';
		}
		echo '</td>';
		// Build the show box but keep it hidden
		echo '</tr>';
		$colcount=0;
		$row = $data_results->fetch(PDO::FETCH_NUM);
	}
	echo '</tbody></table></div>';


/* Global updates
?>
  <div id="global_update"><h3>Global updates</h3>';
    <form name="global_update" id="global_update_form" action="',$_SERVER['PHP_SELF'],'" method="POST">Set <select name="global_update_field">
      <?php
      foreach($fields as $field)
      {
    	  echo '<option value="',$field['name'],'">',$field['name'],'</option>';
      }
      ?>
    </select> as <input name="global_update_value"></input><a href="javascript:void(0)"><img id="global_update_form_submit" src="'.$PMT_DIR_CLIENT.'/images/yes.png" alt="Go"/></a> in checked items</form></div>
  
  <?php
  */

  // Set up dropdown function; needs dropdown.js included in headers
  echo "<script type='text/javascript'><!--";
  foreach($opts['dropdown'] as $dropdown_field=>$dropdown_field_details)
  {
      echo "
	    var details = new Array();
	    details['{$dropdown_field}'] = new Array();
	    details['{$dropdown_field}']['table'] = '{$dropdown_field_details['table']}';
            details['{$dropdown_field}']['keyfields'] = new Array();
   ";
      if (array_key_exists('search_only',$dropdown_field_details))
	  {
	      echo "details['{$dropdown_field}']['search_only'] = {$dropdown_field_details['search_only']};";
	  }
      else
	  echo "details['{$dropdown_field}']['search_only'] = 0";
      if (array_key_exists('multiple',$dropdown_field_details))
      {
	  echo "details['{$dropdown_field}']['multiple'] = {$dropdown_field_details['multiple']};";
      }
      else
	  echo "details['{$dropdown_field}']['multiple'] = 0;";
      $i=0;
      foreach($dropdown_field_details['fields'] as $dropdown_keyfield)
      {
	  echo "
			details['{$dropdown_field}']['keyfields'][{$i}] = '{$dropdown_keyfield}';
			";
	  $i++;
      }
      echo "
			details['{$dropdown_field}']['fields'] = new Array();
			";
      $i=0;
      $primary_key_included = 0;
      foreach($dropdown_field_details['display_fields'] as $dropdown_display_field)
      {
	  if ($dropdown_display_field == $dropdown_field_details['primary_key'])
	  {
	      $primary_key_included = 1;
	      break;
	  }
      }
      if (!$primary_key_included)
      {
	  echo "details['{$dropdown_field}']['fields'][{$i}] = '{$dropdown_field_details['primary_key']}';";
	  $i++;
      }
      
      foreach($dropdown_field_details['display_fields'] as $dropdown_display_field)
      {
	  echo "
			details['{$dropdown_field}']['fields'][{$i}] = '{$dropdown_display_field}';
			";
	  $i++;
      }
      
      echo "
			details['{$dropdown_field}']['textbox'] = '{$dropdown_field}';
			details['{$dropdown_field}']['fillup_field'] = '{$dropdown_field_details['fillup_field']}';
			details['{$dropdown_field}']['primarykey']='{$dropdown_field_details['primary_key']}';
						dropdown_box(details['{$dropdown_field}']);
			";
      
  }
  echo "
	  function fill_dropdown_field(host,db,table,dropdown_box, keyfield, primarykey,fillup_field)
		{
		$.get('get-dropdown-data.php',{
			key:primarykey,
			keyfield: keyfield,
			host: host,
			db: db,
			table:table,
			fillup_field: fillup_field
			},
			function(data)
			{
				$(\"#\"+dropdown_box).val(data);
			});
		}
		--></script>";
    }
  }
?>
