<?php
session_start();
extract($_SESSION);
extract($_GET);
extract($opts);
$dsn = "mysql:host=".$host.";dbname=".$db.";";
try
{
    $dbh = new PDO($dsn, $username, $password);
}
catch (PDOException $e)
{
    echo 'Connection failed: ' . $e->getMessage();
}
$sql = "DELETE FROM `$table` WHERE `$primary_key` = '$pk'";
$res = $dbh->prepare($sql);
try
{
    $res->execute();
    echo $res->rowCount();
}

catch (PDOException $e)
{
    echo $e->getMessage();
}

?>
