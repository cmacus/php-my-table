<?php
session_start();
extract($_SESSION);
extract($opts);
//var_dump($_POST);
//GET contains current_table and current_primary_key name
$current_table = $_GET['current_table'];
$current_primary_key = $_GET['current_primary_key'];

// POST contains actual data
if (isset($opts['readonly']))
    if ($opts['readonly'])
	die("Table is read only!");
$dsn = "mysql:host=".$host.";dbname=".$db.";";
try
	{
	    $dbh = new PDO($dsn, $username, $password,array(PDO::MYSQL_ATTR_FOUND_ROWS => true));
	    $dbh->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
	}
catch (PDOException $e)
{
    echo 'Connection failed: ' . $e->getMessage();
}
$sql = "UPDATE `$current_table` SET ";
foreach($_POST as $key => $value)
{
    if ($key != 'current_table' && $key != 'current_primary_key')
    {
	if ($key != $current_primary_key)
	{
	    $value=addslashes($value);
	    $sql .= "`$key`='$value',";
	}
    }
}
$sql = substr($sql,0,-1);
$sql .= " WHERE `$current_primary_key` = '$_POST[$current_primary_key]'";
try
{
	$res=$dbh->prepare($sql);
	$res->execute();
	echo $res->rowCount();
}
catch (PDOException $e)
{
	echo $e->getMessage()," ",$sql;
}
?>
