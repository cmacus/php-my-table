<html>

  <!-- The default print record page for phpMyTable pages -->
<head>

  <title>Citrus: Print</title>

  <style type="text/css" media="print,screen">
  * {font-family:"helvetica","liberation sans", "arial", "sans-serif";}
  body {margin-left:30px;margin-right:0.3in;}
  </style>

  <style type="text/css" media="print">
  .dont_print {display: none}
  </style>
  
</head>

<body>
  <?php
  session_start();
  extract($_SESSION['opts']);
  extract($_GET);
  if (isset($_GET['table']))
      $table = $_GET['table'];
  else
      $table = $current_table;// If the table has been given in addressbar, take it
  $dsn = "mysql:host=".$host.";dbname=".$db.";";
  try
  {
      $dbh = new PDO($dsn, $username,$password);
  }
  catch (PDOException $e)
  {
      echo 'Connection failed: ' . $e->getMessage();
  }
  require_once('phpMyTable_config.php');
    
  $sql = "SELECT * FROM `$table` WHERE `$primary_key` = '$pk'";
  try
  {
      $res = $dbh->prepare($sql);
      $res->execute();
      $row = $res->fetch(PDO::FETCH_ASSOC);
      foreach($row as $key=>$val)
      {
	  echo '<div class="label" id="',$key,'_label">',$key,':</div>';
	  echo '<div class="value" id="',$key,'_value">',$val,'</div>';
      }
  }
  catch (PDOException $e)
  {
      echo $e->getMessage();
  }
  ?>
</body>
</html>
