var PRESENT_CENTURY = 2000;
UP_KEY=38;
DOWN_KEY=40;
ENTER_KEY=13;
TAB_KEY=9;
ESCAPE_KEY=27;
SPACE_KEY = 32
MIN_REGEXP_LENGTH=4;
error_count=0;

selected_records = [];


function close_edit_mode()
      {
	  $('table#results tr.edit_mode').removeClass('edit_mode').addClass('display_mode');
      }
      

function case_insensitive_make_bold(needle, haystack)
{
    NEEDLE = needle.toUpperCase();
    HAYSTACK = haystack.toUpperCase();
    j = HAYSTACK.indexOf(NEEDLE);
    first = haystack.slice(0,j);
    second = haystack.slice(j, j + needle.length);
    third = haystack.slice(j+needle.length)
    return first+"<b>"+second+"</b>"+third;
}

function convert_select_to_dropdown()
{
    // Convert select to dropdown
    alert('Yes');
    list = new Array();
    $('select').
	each(function()
	     {
		 select_box_id = $(this).attr('id');
		 list[select_box_id] = new Array();
		 
		 options = 0
		 $(this).
		     children('option').
		     each(function()
			  {
			      list[select_box_id][options] = new Array()
			      list[select_box_id][options]['value'] = $(this).val();
			      list[select_box_id][options]['display'] = $(this).html();
			      options++;
			      
			  });
		 if (options > 1)
		 {
		     $(this).hide();
		     input_box = $('<input class="dropdown_after_select" id="dropdown_after_select' + select_box_id + '">').insertAfter($(this));
		     if ($(this).children('option:selected').text() != '---------')
			 input_box.val($(this).children('option:selected').text());
		     input_box.
			 bind('keyup',function(e)
			      {
				  if (e.keyCode == DOWN_KEY)
				  {
				      $('div#fillup'+' ul li:nth-child('+ ++focused_at + ')').addClass('dropdown_selected_item').focus().siblings().removeClass('dropdown_selected_item');
				  }
				  else if (e.keyCode == UP_KEY)
				  {
				      $('div#fillup'+' ul li:nth-child('+ --focused_at + ')').addClass('dropdown_selected_item').focus().siblings().removeClass('dropdown_selected_item');
				  }
				  else if (e.keyCode == TAB_KEY)
				  {
				      $('div#fillup'+' ul li:nth-child('+focused_at+')').click();
				  }
				  else
				  {
				      key = $(this).val();
				      if (key.length > MIN_REGEXP_LENGTH)
				      {
					  calling_select = $(this).siblings('select');
					  calling_box = $(this)
					  t = calling_box.offset().top;
					  l = calling_box.offset().left;
					  w = parseInt(calling_box.css('width'));
					  matched=0;
					  select_box_id = calling_select.attr('id');

					  
					  if (key)
					  {
					      fillup_str = "<ul>";
					      matched=0;
					      i=0;
					      $(calling_select).children('option').each(function()
											{
											    display = list[select_box_id][i]['display'];
											    if (display.toUpperCase().indexOf(key.toUpperCase()) >= 0)
											    {
												matched++;
												fillup_str += '<li  class="dropdown_choice" value="'+ list[select_box_id][i]['value'] + '"><a href="javascript:void(0)">'+ case_insensitive_make_bold(key,display) + '</a></li>';
												
											    }
											    i++;
											});
					      fillup_str +="</ul>";
					      $('div#fillup').css('top',t+50).css('left', l + 20).html(fillup_str).slideDown().find('li.dropdown_choice')
						  .click(function(e)
							 {
							     
							     calling_box.val($(this).text());
							     $('div#fillup').hide();
							     v = $(this).attr('value');
							     calling_select.val($(this).attr('value'));
							     calling_select.children('option[value='+v+']').prop('selected',true);
							     
							     focused_at=0;
							 });
					  }
					  else
					  {
					      $('div#fillup').hide();
					      focused_at=0;
					  }
				      if (!matched)
					  $('div#fillup').html('<span class="dropdown_error">No match</span>');
				      }
				  } 
			      });
		 }
	     });
    $(':not(div#fillup)').click(function()
				{
				    $('div#fillup').hide();
				});
}

function check_last_word(box)
{
    console.log(box.val());
}

function flash_notice(data)
{
    $('div.notice').hide('fast').slideDown('fast').children('div#notice_text').html(data);
}

function hide_notice()
{
    $('div.notice').hide();
}
function open_multiple_entry_table(table,foreign_key,primary_key)
{
    window.open(table.toLowerCase()+'.php?reset=1&new=1&'+ foreign_key + '='+ $('label#row_id').text());
}

function capitalize(text)
{
    return(text.toUpperCase());
}

function convert_text_to_date(str, output_separator) // Make a date like 01 Sep 15 or 1/9/15 to 2015-09-01
{
    if (str.match('/')) {
	separator = '/';
    }
    else
	separator = ' ';
    var parts = str.split(separator);
    var months = ['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];
    for (i=0;i<12;i++)
    {
	if (isNaN(parts[1]))
	    {
		if (months[i].toUpperCase() == parts[1].toUpperCase())
		{
		    selected_month = i+1;
		}
	    }
	else
	{
	   selected_month = parts[1];
	}
    }
    if (selected_month < 10)
	selected_month = '0' + selected_month;
    selected_year = (parts[2].length < 3) ? parseInt(parts[2]) + PRESENT_CENTURY : parts[2];
    selected_date =  (parts[0].length < 2) ? '0' + parts[0]: parts[0];
    if (selected_date > 31 || selected_month > 12)
	return null;
    else
	return(selected_year+output_separator+selected_month+output_separator+selected_date);
}

$(function()
  {
      
      $('.action_buttons').hide();
      current_table = $('div#current_table').html(); // Set current table
      current_primary_key = $('div#page_details span#primary_key').html();
      $('#sql').hide().fadeOut('fast').fadeIn('fast')
      
      $('table#results input, table#results textarea,table#results a, table#results button').
	  focus(function()
		{
		    $(this).parents('td').addClass('active');
		    $(this).parents('tr').addClass('active');
		}
	       );
      $('table#results input, table#results textarea,table#results a').
	  blur(function()
	       {
		   $(this).parents('td').removeClass('active');
		   $(this).parents('tr').removeClass('active');
	       }
	      );
      if ($('table#results tr.result')) $('tr#new_result').hide();

      // bind change event to select box (page number)
      $('div.paginate').clone().insertAfter('#results').addClass('paginate_lower');
      $('select.page_numbers').
	  change(function()
		 {
		     var pagenum = $(this).val();
		     if (pagenum) // require a URL
		     {
			 window.location.href = window.location.pathname + "?page_number=" + pagenum; // redirect
		     }
		 });
      
      // Search form submit on change of dropdown
      $('select.search').change(function()
				{
				    $('form.search_form').submit();
				});

      // Search form submit on clicking search image
      $('#search_button').click(function(event)
				{
				    event.preventDefault();
				    $('form.search_form').submit();
				});
      
      $('div#show').hide();

      $('.show_button').click(function()
			      {
				  $('div#show').fadeIn('fast');
				  $('div#show div#content').html('');
				  $(this).parents('tr').find('.field').each(function()
				  					    {
				  						$('div#show div#content').append('<div class="show_field"><strong>' + $(this).attr('name') + '</strong> : ' + $(this).val() + '</div>');
				  					    });
			      });
      
      $('div#show .close_button').click(function()
			      {
				 	 $('div#show').hide();
			      });
      $('div#new div.close_button a').click(function()
					    {
						$('div#new').hide();
					    });

      $('.delete_button').click(function()
				{
				    calling_row = $(this).parents('tr');
				    primary_key = $(this).parents('tr').attr('id');
				    if (confirm("Really delete record " + primary_key + " ?"))
				    {
					$.get(PMT_DIR_CLIENT + '/delete.php', {pk : primary_key}, function(data)
					      {
						  console.log(data);
						  flash_notice( (data == 0) ? "Failed to delete record! Check privileges and related tables " : "Record " + primary_key + " deleted (" + data + " row(s))");
						  if (data > 0)
						      $(calling_row).remove();
					      });
				    }
				});

 
      
      $('table#results .field').blur(function()
				     {
					 //console.log($(this).parents('td').siblings('form.update_form').serialize());
					 if ($(this).parents('tr').find('form').attr('changed') == 'true') // If this row has been modified
					 {
					     $.post(PMT_DIR_CLIENT + "/update.php?current_table="+current_table+"&current_primary_key="+current_primary_key,$(this).parents('td').siblings('form.update_form').serialize(),function(data)
						    {
							console.log(data);
							//window.location.reload();
							if (data > 0)
							{
							    flash_notice(data + " record updated");
							}
							else
							{
							    flash_notice("Failed to update record! Check privileges and related tables");
							}
						    });
					     
					 }
					 else
					 {
					     hide_notice();
					 }
				    });
      $('.new_button').click(function()
			     {
				 $('div#new').fadeIn('fast');
			     });
      
      $('tr.display_mode').append('<a class="edit_close_button dont_print" onclick="close_edit_mode()" href="javascript:void(0)" target="_blank"><img src="'+PMT_DIR_CLIENT + '/images/close.png"></a>');

      $('.edit_button').click(function()
			      {
				  primary_key = $(this).parents('tr').attr('id');
				  $(this).parents('tr').
				      removeClass('display_mode').
				      addClass('edit_mode');
			      });      
           $('div#new form.record_form').submit(function(event)
						{
						    $('div#new input[type=submit]').attr('disabled','disabled');
						    event.preventDefault();
						    
						    $('label#insert_wait').html('Please wait...');
						    newdata= $(this).serializeArray();
						    console.log($(this).serialize());
						    $.getJSON(PMT_DIR_CLIENT + "/write.php",$(this).serialize(),function(data)
							 {
							     
							     flash_notice(data.result);
							     $('label#row_id').html(data.row_id).show();
							     $('span#print_record a').attr('href',($('span#print_record a').attr('href') + '&pk=' + data.row_id));
							     if (data.row_id)
							     {
								 new_row = '<tr class="new_row"><td></td>';
								 for (d in newdata)
								 {
								     if (d > 0) // Skip the first field, which is current table
									 new_row += '<td>'+newdata[d]['value']+'</td>';
								 }
								 new_row += '</tr>';
								 $('table#results tr.search').after(new_row);
								 console.log(newdata);
							     }
							 });
						    $('label#insert_wait').html('');
						    $('div#new input[type=submit]').removeAttr('disabled');
						    $('div#new form.record_form input:first').focus();
					   });
      
      $('table#results tr.display_mode').hover(function(event)
			     {
				 $(this).find('.action_buttons').show();
			     },
			     function()
			     {
				 $(this).find('.action_buttons').hide();
				 
			     });


      $('div#new .field').focus(function()
				{
				    $(this).addClass('active');
				    $('span.suggestion').remove();
				    $('<span class="suggestion"/>').insertAfter(this).html($(this).attr('suggestion'));
				});
      $('div#new .field').blur(function()
			       {
				   $(this).removeClass('active');
			       });

      // Select records
      $('input.selected').click(function()
				{
				    primary_key = $(this).parents('tr').attr('id');
				    
				    if ($(this).attr('checked')=='true')
				    {
					deselect_this_record(primary_key);
					
				    }
				    else
				    {
					select_this_record(primary_key);
				    }
				});

      function select_this_record(primary_key)
      {
		selected_records.push(primary_key);
      }

      function deselect_this_record(primary_key)
      {
		selected_records.pop(primary_key);
      }

      $('input#select_all').click(function()
				  {

				      if ($(this).attr('checked')==true) // To be selected
					  {
					      $('table#results tr').each(function()
									 {
									     select_this_record($(this).attr('id'));
									 });
					      $('input.selected').attr('checked',true);
					  }
				      else
					  {
					      $('table#results tr').each(function()
									 {
									     deselect_this_record($(this).attr('id'));
									 });

					      $('input.selected').attr('checked',false);
					  }
				  });


      // Global update form
      $('#global_update_form_submit').click(function()
					    {
						$('form#global_update_form').submit();
					    });
      
      // New record form
      $('img#Add').click(function()
			 {
						$('div#new form.record_form').submit();
					      });


      // Add a calendar to date-time fields
      date_field_count=0;

      // Only date in search row
      $('input.date_field.search').each(function()
					{
					    date_field_count++;
					    new_button = ' <button class="trigger_calendar" id="date_button_' + date_field_count +'">...</button>';
					    $(this).after(new_button);
					    
					    // $(this).attr('id','date_field_'+ date_field_count + "_" + row_id);
					    Calendar.setup (
						{
						    inputField : $(this).attr('id'),
						    ifFormat: "%Y-%m-%d",
						    button: $(this).next('button.trigger_calendar').attr('id'),
						    showsTime: false,
						    weekNumbers: false
						});
					});

      // Date and time in table body
      $('input.date_field.field').each(function()
				       {
					   date_field_count++;
					    new_button = ' <button class="trigger_calendar" id="date_button_' + date_field_count +'">...</button>';
					    $(this).after(new_button);
					   Calendar.setup (
				               {
						   inputField : $(this).attr('id'),
						   ifFormat: "%Y-%m-%d %H:%M:%S",
						   button: $(this).next('button.trigger_calendar').attr('id'),
						   showsTime: true,
						   weekNumbers: false
					       });
				       });
      $('input.date_field').each(function()
				 {
				     $(this).blur(function()
						  {
						      $(this).val(convert_text_to_date($(this).val(),'-'));
						  });
				 });
      
      $('div.notice a#close_notice').click(function()
					     {
						 $('div.notice').hide();
					     })


      // Click fields
      $('input.click_field').dblclick(function()
				      {
					  window.open($(this).attr('click_table_page') + '?search=1&' + $(this).attr('click_primary_key') + '=' + $(this).val());
				      });

      // Escape key functions
      $('body').keydown(function(e)
			{
			    if (e.keyCode == ESCAPE_KEY)
			    {
				$('div#new').hide();
				$('table#results tr.edit_mode').removeClass('edit_mode').addClass('display_mode');
				$('div#show').hide();
			    }
			});

      // Input validations - email, capital, required, numeric, character with length, password with required characters, low and high normals to mark
      $('input.numeric, textarea.numeric').blur(function()
						{
						    if ($(this).val()!='')
						    {
							if (isNaN($(this).val()))
							{
							    $('span.validation_warning_numeric').html('').remove();
							    $(this).after('<span class="validation_warning_numeric">Please enter numbers only</span>');
							    $(this).focus();
							}
							else
							    $('span.validation_warning_numeric').html('').remove();
						    }
						}
					       );
      $('input.required, select.required, textarea.required').blur(function()
								   {
								       if ($(this).val()=='')
								       {
									   $('span.validation_warning_required').html('').remove();
									   $(this).after(' <span class="validation_warning_required">This is a required field</span>');
									   $(this).focus();
								       }
								       else
									   $('span.validation_warning_required').html('').remove();
								   });
      
      $('input.character, textarea.character').blur(function()
						    {
							if ($(this).val())
							    
							{
							    if (!isNaN($(this).val()))
							    {
								$('span.validation_warning_character').html('').remove();
								$(this).after(' <span class="validation_warning_character">No numbers, only characters</span>');
								$(this).focus();
							    }
							    else
								$('span.validation_warning_character').html('').remove();
							}
						    });
      $('input.capital, textarea.capital').blur(function()
						{
						    $(this).val(capitalize($(this).val()));
						});
	$('input[type=number]').blur(function()
	{
		val = parseFloat($(this).val());
		normallow = parseFloat($(this).attr('normallow'));
		normalhigh = parseFloat($(this).attr('normalhigh'));
		if (val < normallow || val > normalhigh)
		{
			$(this).addClass('out_of_range_entry');
			$('span.validation_warning_numeric').html('').remove();
			$(this).after('<span class="validation_warning_numeric">Out of range! Please recheck</span>');
		}
		else
		{
			$(this).removeClass('out_of_range_entry');
			$('span.validation_warning_numeric').html('').remove();
		}
			
	});

      // Track if a row is being changed
      $('table#results .field').change(function()
				       {
					   $(this).parents('tr').find('form').attr('changed','true');
				       });
      //Navigation within results table
      $('table#results .field').keydown(function(e)
					     {
						if (!$('div#fillup').is(':visible')) // If a dropdown is active, let it have focus
						{
							 fieldName = $(this).attr('name');
							 if (e.keyCode == DOWN_KEY)
							     $(this).parents('tr').next().find('input.field[name='+fieldName+']').focus();
							 else if (e.keyCode == UP_KEY)
								     $(this).parents('tr').prev().find('input.field[name='+fieldName + ']').focus();
						}	
					     });

      
      // Select option in select boxes in main table
      $('table#results tr td.field_cell select.field').each(function()
							    {
								if ($(this).attr('value'))
									$(this).children('option[value='+$(this).attr('value')+']').attr('selected','true');
							    });

  });
