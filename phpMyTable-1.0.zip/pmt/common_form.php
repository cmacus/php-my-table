<?php
echo '<form name="record_form" class="record_form">';
$i = 0;

// Name of current table
echo '<input type="hidden" name="current_table" value="',$current_table,'"/>';

for ($i=0;$i<count($fields);$i++)
{
    echo '<div class="field ', $fields[$i]['name'],'">'; // The div containing the entry
    echo '<div class="label"><label class="',$fields[$i]['name'],' '; // The label for the entry
    if ($opts['primary_key']==$fields[$i]['name'])
	echo $opts['$primary_key']; // If this field is primary key, add it to the class of the label
    echo '">',$fields[$i]['name'],'</label></div>';
    echo '<div class="new_value">'; // The div containing the input/select box
    if (array_key_exists($fields[$i]['name'],$opts['defaults'])) // If this field has a default value supplied by $opts
    {
	$def_value = $opts['defaults'][$fields[$i]['name']];
    }
    
    // Construct the type of input box
    if (in_array($fields[$i]['name'],$opts['text_fields'])) // Text field
	echo '<textarea ';
    elseif (array_key_exists($fields[$i]['name'],$opts['refs'])) // This field is a reference
	echo '<select ';
    elseif (array_key_exists($fields[$i]['name'],$opts['input_max_val']) || array_key_exists($fields[$i]['name'],$opts['input_min_val']) || array_key_exists($fields[$i]['name'],$opts['input_normal_ranges']))
	echo '<input type="number" step="any" ';
    else
	echo '<input type="text" ';

  // Autofocus attribute
   if ($opts['initial_focus'] == $fields[$i]['name'])
	echo ' autofocus ';

    // Construct the attributes of the input box
    echo 'title="', $fields[$i]['name'] ,'" ', // The title
	'name="',$fields[$i]['name'],'" ', // Name for form purpose
	'placeholder="',$fields[$i]['name'],'" ',// Placeholder value
	
	// Class attribute begins
	'class="field ',$fields[$i]['name']; // Class - includes 'field', the name of the field
    
    if ($opts['primary_key'] == $fields[$i]['name']) // If this is the primary key, add it to class
	echo ' primary_key';
    if ($fields[$i]['native_type'] == 'TIMESTAMP' || $fields[$i]['native_type'] == 'DATE' || $fields[$i]['native_type'] == 'DATETIME') // Date time field, add a class to attach the calendar later
	echo ' date_field ';
    if (isset($opts['input_validations'][$fields[$i]['name']]))
    {
	foreach($opts['input_validations'][$fields[$i]['name']] as $validation_key=>$validation_value)
	{
	    echo ' '.$validation_value; // Whether numeric, character, email
	}
    }
    echo '" '; // Class attribute ends
    
    if (isset($opts['input_max_lengths'][$fields[$i]['name']]))
    {
	echo ' maxlength="',$input_max_lengths[$fields[$i]['name']],'"';
    }

   if (isset($opts['input_max_val'][$fields[$i]['name']]))
	{	
		echo ' max="',$opts['input_max_val'][$fields[$i]['name']],'"';
	}

    if (isset($opts['input_min_val'][$fields[$i]['name']]))
	{
		echo ' min="',$opts['input_min_val'][$fields[$i]['name']],'"';
	}
    if (isset($opts['input_normal_ranges'][$fields[$i]['name']]))
	{
		echo ' normallow="',$opts['input_normal_ranges'][$fields[$i]['name']]['NormalLow'],'" normalhigh="', $opts['input_normal_ranges'][$fields[$i]['name']]['NormalHigh'],'"';
	}
    echo ' id="';
    //if ($opts['dropdown'][$fields[$i]['name']]) // This fields needs a dropdown box, needs dropdown.js
    //    echo $fields[$i]['name'],'_dropdown'; // Add a '_dropdown' after its id
    //else
    echo $fields[$i]['name'];
    echo '" '; // Id attribute ends

    if (in_array($fields[$i]['name'], $opts['readonly_fields']) || in_array($fields[$i]['name'], $opts['hidden_inputs']) || in_array($fields[$i]['name'],$opts['invisible'])) // If this field does not need input, i.e. not hidden in new record form
    {
	echo 'readonly="true" ';
    }
    if (isset($opts['input_suggestions'][$fields[$i]['name']]))
	echo 'suggestion="',$opts['input_suggestions'][$fields[$i]['name']],'" ';
    echo 'value="';
    if (array_key_exists('new',$_GET) && isset($_GET[$fields[$i]['name']])) // If the address bar has given the 'new' parameter and default value for a field
    {
	echo $_GET[$fields[$i]['name']];
    }
    if (isset($opts['defaults'][$fields[$i]['name']]))// If this has a default value set by $opts parameters
    {
	echo $def_value;
    }
    echo '">';
    
    if (in_array($fields[$i]['name'],$opts['text_fields'])) // Text field
    {
	if (isset($opts['defaults'][$fields[$i]['name']]))// If this has a default value set by $opts parameters
	{
	    echo $def_value;
	}
	echo '</textarea></div>';
    }
    elseif ($opts['refs'][$fields[$i]['name']]) // This is a reference
    {
	$ref = $opts['refs'][$fields[$i]['name']]; // Construct the select box from parameters supplied by foreign key, table and display field
	if ($ref['foreign_key']) // If this refrence points to values on another table
	{
	    $ref_sql = "SELECT ". $ref['foreign_key'] . ", " . $ref['display_field'] . " FROM " . $ref['table'];
	    if (isset($ref['order']))
		$ref_sql.=" ORDER BY ".$ref['display_field']." ".$ref['order'];
	    
		$ref_results = $dbh->prepare($ref_sql);
	    $ref_results->execute();
	    echo '<option value=""></option>';
	    while($ref_row=$ref_results->fetch(PDO::FETCH_ASSOC))
	    {
		echo '<option value="',$ref_row[$ref['foreign_key']],'"';
		if (isset($_GET[$fields[$i]['name']])) // If the address bar has given the value for a field
		{
		    if ($_GET[$fields[$i]['name']] == $ref_row[$ref['foreign_key']])
			echo ' selected ';
		}
		if (isset($opts['defaults'][$fields[$i]['name']]))
		{
			if ($def_value == $ref_row[$ref['foreign_key']])
			    echo ' selected ';
		}
		echo '>',$ref_row[$ref['display_field']],'</option>';
	    }
	    echo '</select></div>';
	}
	else // For enum fields specified in $opts['refs'], which have no table associated
	{
	    foreach ($ref as $val)
	    {
		echo '<option value="',$val,'"';
		if (isset($_GET[$fields[$i]['name']]) &&  $_GET[$fields[$i]['name']] == $val)
		    echo ' selected ';
		if (isset($opts['defaults'][$fields[$i]['name']]))
		{
		    if ($def_value == $val)
			echo ' selected ';
		}
		echo '>',$val,'</option>';
	    }
	    echo '</select></div>';
	}
	
    }
    else
	echo '</input></div>';
    echo '</div>';
}
unset($def_row);
echo '<p><input type="submit"></input></form>';
?>
