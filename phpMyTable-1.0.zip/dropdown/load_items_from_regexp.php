<?php
session_start();

// Credentials
extract($_POST);
extract($_SESSION); // $username, $password, $db, $host need to be in $_SESSION

// Configuration
$SELECTED_ITEM_BGCOLOR = "#efabab";

// Connection
$dsn = "mysql:host=".$host.";dbname=".$db.";";
	try
	{
	    $dbh = new PDO($dsn, $username, $password);
	}
	catch (PDOException $e)
	{
	    echo 'Connection failed: ' . $e->getMessage();
	}

// Build SQL
$sql = "SELECT ";
foreach($fields as $field)
{
    $sql .= " `{$field}`,";
}
$sql = substr($sql, 0, -1);
$sql .= " FROM `{$table}` WHERE ";

foreach($keyfields as $keyfield)
{
    $sql .= "`{$keyfield}` REGEXP '{$key}' OR ";
}
$sql = substr($sql,0, -4);	 // Remove the last OR

$res = $dbh->prepare($sql);
$res->execute();

//echo "<br/>",$res->rowCount(), "matches";
if (!$res->rowCount()) die('No match');

// Fillup the dropdown div
$str_before_text = $str_text = $str_after_text =null;

if ($res->rowCount() > 0 )
  echo "<ul>";
else
    die();

while($row = $res->fetch(PDO::FETCH_ASSOC))
{
    $str_before_text = '<li title="'.$row[$fillup_field].'"><a href="javascript:void(0)">';
    $str_text = null;
    foreach($fields as $field)
    {
        $str_text .= $row[$field]." ";
    }
    $str_text = substr($str_text,0,-1);
    
    $str_text = preg_replace("/(?i)$key/","<strong>$0</strong>",$str_text); // Make the matched string bold
    $str_after_text = '</a></li>';
    echo $str_before_text.$str_text.$str_after_text;
}
echo "</ul>";
