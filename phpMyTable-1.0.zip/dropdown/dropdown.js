// Dropdown.js
// Attach a text box to a field in a database, so that regexp search is possible
// Requires jQuery, PHP

MIN_KEY_LENGTH=3
MAX_KEY_LENGTH=15
UP_KEY=38;
DOWN_KEY=40;
ENTER_KEY=13;
TAB_KEY=9;
ESCAPE_KEY=27;
BACKSPACE_KEY = 8;
SPACE_KEY = 32;
LOCAL_SEARCH_BUFFER_LENGTH = 3;
var focused_at = 0;
var local_search_mode = 0; // If 1, search within the div instead of calling the server
DROPDOWN_APP_PATH_CLIENT = '/apps/dropdown';

function dropdown_box(details) // Details is an array holding all the data
{
    textbox = details['textbox'];
    if (details['multiple']) // A class of textboxes
    {
        selector = 'input.'+textbox;
    }
    else
        selector = 'input#'+textbox; // Only a single textbox
    $(selector).bind('keyup',function(e)
		     {
			 
			 this_box = $(this);
			 needle = this_box.val();
			 if (e.keyCode == DOWN_KEY)
			 {
			     selected_line = $('div#fillup ul li:nth-child('+ ++focused_at + ')');
			     selected_line.addClass('dropdown_selected_item').focus().siblings().removeClass('dropdown_selected_item');
			 }
			 else if (e.keyCode == UP_KEY)
			 {
			     selected_line = $('div#fillup ul li:nth-child('+ --focused_at + ')');
			     selected_line.addClass('dropdown_selected_item').focus().siblings().removeClass('dropdown_selected_item');
			 }
			 else if (e.keyCode == TAB_KEY)
			 {
			     if (focused_at > 0)
			     {
				 selected_line = $('div#fillup ul li:nth-child('+ focused_at + ')');
				 
				 if (details['search_only']==0) // This field HAS TO BE filled up from the dropdown
				 {
				     fillup_dropdown_box_from_list(selected_line,this_box,details['custom_onclick']);
				 }
			     }
			 }
			 else if (e.keyCode == BACKSPACE_KEY)
			 {
			     $('div#fillup').find('li').each(function()
							     {
								 this_line = $(this).text();
								 if (this_line.search(needle.toUpperCase()) == -1)
								 {
								     $(this).hide();
								 }
								 else
								     $(this).show();
							     });
			     
			 }
			 
			 else if (e.keyCode == SPACE_KEY && needle.length > MIN_KEY_LENGTH + LOCAL_SEARCH_BUFFER_LENGTH)
			 {
			     local_search_mode = 1;
			 }
			 
			 else
			 {
			     if (needle.length <= MIN_KEY_LENGTH)
				 local_search_mode= 0;
			     if (local_search_mode)
			     {
				 console.log('Local');
				 $('div#fillup').find('li').each(function()
								 {
								     this_line = ($(this).text()).toUpperCase();
								     
								     if (this_line.search(needle.toUpperCase()) == -1)
								     {
									 $(this).hide();
								     }
								     else
									 $(this).show();
							       });
								  
			     }
			     
			     else
			     {
				 console.log('Server');
				 table = details['table'];
				 keyfields = details['keyfields']; // The fields to search for
				 fields = details['fields']; // The fields to show
				 fillup = details['fillup'];
				 primarykey = details['primarykey'];
				 fillup_field = details['fillup_field'];
				 calling_field = $(this);
				 t = calling_field.offset().top;
				 l = calling_field.offset().left;
				 w = parseInt(calling_field.css('width'));
				 var key = calling_field.val();
				 if (key.length >MIN_KEY_LENGTH && key.length<MAX_KEY_LENGTH)
				 {
				     $.post(DROPDOWN_APP_PATH_CLIENT + "/load_items_from_regexp.php",
					    { table: table,
					      keyfields : keyfields,
					      fields : fields,
					      key: key,
					      primarykey: primarykey,
					      fillup_field:fillup_field,
					      focused_at:focused_at
					    },
					    function(data)
					    {
						if (!data)
						{
						    $('div#fillup').hide();
						    focused_at=0;
						}
						else
						{
						    $('div#fillup').
							html(data).
							css('top',t).
							css('left', l + w+ 10).
							slideDown().
							find('li').
							bind('click',function()
							     {
								 
								 selected_line = $(this);
								 if (details['search_only'] == 0)
								 {
								     fillup_dropdown_box_from_list(selected_line,this_box,details['custom_onclick']);
								 }
							     });
						}
					    });
				 }
			     }
			 }
		
		     });
		   

function fillup_dropdown_box_from_list(selected_line, selector, custom_onclick) // Both query objects
{
    v = selected_line.attr('title');
    selector.val(v);
    selected_line.parents('div#fillup').hide();
    if (custom_onclick)
    {
	var F=new Function (custom_onclick);
	return(F());
    }
}

$('body').click(function ()
		{
                    $('div#fillup').fadeOut();
                    focused_at=0;
		});
}
